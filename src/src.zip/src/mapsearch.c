/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
#include "mapsearch.h"

MaxResults NearOptMapSearch(Model B, MaxResults maxData, PoSition **Pos)
{
  int        i;
  int        t;
  int        n;
  Mlist      M;
  ProbStruct P;
  IPtype     IP;
  int        nSeq;
  int        newpos;
  int        typ;
  double     bestMap;
  double     currMap;
  double     fwdMap;
  double     revMap;
  int        maxnum;
  MaxResults currMax;
  double     **dProbArray;
  int        last_inc;
  double     dMax;
  double     dLocMax;

  IP = B->IP;

  copy_counts(B);
  for( i = 0; i < B->IP->nNumSequences; i++ )
    B->RP->nSites[i] = 0;
  
  M = initializeMotifs(B->IP);                    /* now add in the */
  for(t = 0; t < IP->nNumMotifTypes; t++)      /* motifs in the  */
    {                                             /* max alignment  */
      IP->nNumMotifs[t][FORWARD] = 0;
      IP->nNumMotifs[t][REVERSE] = 0;
      for(i = 0; i < maxData.nNumMotifs[t]; i++) 
	{ 
	  adjust_counts(B, ADD, maxData.nMotifLoc[i][t], t, maxData.RevComp[i][t]);
	  add_motif(B->IP, B->Seq, maxData.nMotifLoc[i][t],M,t, 
		    maxData.RevComp[i][t]);
	  set_in_motif(Pos,maxData.nMotifLoc[i][t],B,t,
		       maxData.RevComp[i][t]);
	  IP->nNumMotifs[t][maxData.RevComp[i][t]]++;
	  B->RP->nSites[SequenceFromPosition( B,  maxData.nMotifLoc[i][t] )]++;
	}
    }

  P.update = TRUE;
  init_prob(&P, IP);
  update_prob(&P, B->C, IP, TRUE);
  
  do
    {
      startMap = CalcMapProb( B, IP->is_defined[cl_R] );
      bestMap = startMap;
      for( n = 0; n < IP->nSeqLen; n++ )
	{
	  nSeq = SequenceFromPosition( B,  n );
	  for(t = 0; t < IP->nNumMotifTypes; t++) 
	    {
	      if(((B->IP->is_defined[cl_E] && 
		   B->RP->nSites[nSeq] < B->RP->nMaxBlocks) || 
		  (! B->IP->is_defined[cl_E])) &&
		 PossFragStartPos(Pos, n, t, B) &&     
		 ! OverlapsPrevMotif(n,B->IP->nNumMotifTypes,Pos) &&  
		 ! Pos[t][n].nMotifStartPos) 
		{
		  newpos = -1;
		  if( AnyOverlap(B, n, t, Pos, &newpos, &typ) )
		    {
		      adjust_counts(B,DELETE,newpos,typ,Pos[typ][newpos].RevComp);
		      B->IP->nNumMotifs[typ][Pos[typ][newpos].RevComp]--;
		      B->RP->nSites[nSeq]--;
		      not_in_motif(Pos,newpos,B,typ);
		    } 
		  
		  currMap = CalcMapProb(B, B->IP->is_defined[cl_R]); 
		  
		  adjust_counts(B, ADD, n,t,FALSE);
		  B->RP->nSites[nSeq]++;	      
		  B->IP->nNumMotifs[t][FORWARD]++;	
		  fwdMap = CalcMapProb(B, B->IP->is_defined[cl_R]);
		  adjust_counts(B, DELETE, n,t,FALSE);
		  B->RP->nSites[nSeq]--;
		  B->IP->nNumMotifs[t][FORWARD]--;	
		  		  
		  if(B->IP->RevComplement) 
		    {
		      adjust_counts(B, ADD, n,t,TRUE);
		      B->RP->nSites[nSeq]++;
		      B->IP->nNumMotifs[t][REVERSE]++;
		      revMap = CalcMapProb(B, B->IP->is_defined[cl_R]);
		      adjust_counts(B, DELETE, n,t,TRUE);
		      B->RP->nSites[nSeq]--;
		      B->IP->nNumMotifs[t][REVERSE]--;
		    }
		  else
		    revMap = -DBL_MAX;
		  
		  if( (fwdMap > currMap) && (fwdMap >= revMap) && (fwdMap > bestMap) )
		    {
		      adjust_counts(B, ADD, n,t, FALSE);
		      B->RP->nSites[nSeq]++;
		      B->IP->nNumMotifs[t][FORWARD]++;
		      bestMap = fwdMap;
		      set_in_motif(Pos,n,B,t,FALSE);
		      n += MotifWidth( B, t ) - 1;
		    }
		  else if( B->IP->RevComplement && (revMap > currMap) && (revMap > bestMap) )
		    {
		      adjust_counts(B, ADD, n,t, TRUE);
		      B->RP->nSites[nSeq]++;
		      B->IP->nNumMotifs[t][REVERSE]++;
		      bestMap = revMap;
		      set_in_motif(Pos,n,B,t,TRUE);
		      n += MotifWidth( B, t ) - 1;
		    }
		  else if( newpos >= 0 )
		    {
		      adjust_counts(B, ADD,newpos,typ,Pos[typ][newpos].RevComp);
		      B->IP->nNumMotifs[t][Pos[typ][newpos].RevComp]++;
		      set_in_motif(Pos,newpos,B,typ, Pos[typ][newpos].RevComp);
		      B->RP->nSites[nSeq]++;
		    }           	      
		}
	    }
	}
    } while( bestMap > startMap );

  maxnum = findMaxNumMotif(B->IP);
  
  init_maxdata(&currMax);

  init_prob( &P, B->IP );	
  update_prob( &P, B->C, B->IP, TRUE  );
  update_posterior_prob(B);
  
  dProbArray = setElementProb( B, Pos, P );
  
  currMax = setMaxData(B->F, B->IP, bestMap, 1, Pos, &last_inc, &dMax,
		       &dLocMax, currMax, dProbArray, B);
  FREEP(dProbArray, maxnum); 

  currMax.frequency = NULL; 

  print_info(B, currMax);
  
  return currMax;
}

