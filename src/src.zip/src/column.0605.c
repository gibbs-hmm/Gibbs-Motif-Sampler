/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/**************************************************************************/
/* $Id: column.0605.c,v 1.4 2007/05/23 18:19:55 Bill Exp $            */
/*                                                                        */
/* Author :       Eric C. Rouchka May 29, 1996                            */
/*                Jun Zhu, October 20, 1996                               */
/*                                                                        */
/* Description :  Contains the function ColumnShift which takes the       */
/*                alignment, shifts it left and right, and samples one of */
/*                the alignments based on the map probability of each of  */
/*                the alignments                                          */
/**************************************************************************/


#include "column.h"



/********************   ColumnShift   *****************************/
/*                                                                */
/*                                                                */
/* DESCRIPTION : This function takes the current motif alignment, */
/*               shifts it left and right, and samples one of     */
/*               those alignments based on the map probability of */
/*               each of the alignments                           */
/******************************************************************/

void ColumnShift(Model B, Mlist M, PoSition **Pos, ProbStruct *P) 

{
    int maxleft, maxright, currleft, currright, shift;
    int index, t, temp, tmp, tmpleft=1000, tmpright=1000;
    register int i; /* general register */
    double *ProbArray, dprob, tprob=0.0, totprob=0.0;
    unsigned short FOUND;
    MlistEl *curr;
    PoSition *Pos_t;  /* Pos_t=Pos[t]  */
    int      oldPos;
    Stype    Seq;
    double   dMotifProb, dBGProb;      /* BT 12/17/97 */

    Seq = B->Seq;
    if(M != NULL)  
      {
        for(t = 0; t < B->IP->nNumMotifTypes; t++) 
	  {
	    maxleft = maxright = (M[t]->nMotifLen / 2);
	    
	    Pos_t=Pos[t];     /* BT 6/13/97 */    
	    /* Make sure moving left and right doesn't cause overlap */
	    oldPos = -1;
	    for(i=0;i<B->IP->nSeqLen;i++)
	      {
		if( Pos_t[i].nMotifStartPos )
		  {
		    if( (oldPos != -1) && (Pos_t[i].nSeq == Pos_t[oldPos].nSeq) )
		      { 
			if(Pos_t[oldPos].RevComp && (! Pos_t[i].RevComp))
			  {
			    if( maxleft > (i - (oldPos + M[t]->nMotifLen)) / 2 )
			      maxleft = (i - (oldPos + M[t]->nMotifLen)) / 2;
			  }
			else if((! Pos_t[oldPos].RevComp) && Pos_t[i].RevComp)
			  {
			    if( maxright > (i - (oldPos + M[t]->nMotifLen)) / 2 )
			      maxright = (i - (oldPos + M[t]->nMotifLen)) / 2;
			  }
		      }
		    if( maxleft < 0 || maxright < 0 )    /* Debug */
		      i = i;
		  oldPos = i;
		  }
	      }
	    
	    curr = M[t]->Motifs;
	    while(curr != NULL) 
	      {                      /* Determine the max */
		currleft = curr->pos - curr->left - 1;      /* number of columns */
		if( curr->right > (*Seq->nvEndLocs)[curr->seq_num] - M[t]->nMotifLen )
		  currright = (*Seq->nvEndLocs)[curr->seq_num] - M[t]->nMotifLen  - curr->pos;
		else
     /*		  currright = curr->right - curr->pos - 1; *//* the alignment can */
		  currright = curr->right - M[t]->nMotifLen - curr->pos;    /* the alignment can */

		currright = max( 0, currright);
		currleft = max( 0, currleft);

		if (curr->RevComp) 
		  {
		    tmp = currleft;
		    currleft = currright;
		    currright = tmp;
		  }

		if(currleft < maxleft)                  /* be shifted left   */
		  maxleft = currleft;                  /* and right         */
		if(currright < maxright)
		  maxright = currright;
		if( maxleft < 0 || maxright < 0 )    /* Debug */
		  i = i;
		curr = curr->next;
	      }
	    if(tmpleft > maxleft)
	      tmpleft = maxleft;
	    if(tmpright > maxright)
	      tmpright = maxright;
	  }
	maxleft = tmpleft;
	maxright = tmpright;
      }
    NEW(ProbArray, maxleft+maxright+1, double);

    /* now Pos is reset. The alignment is maintained in motif list M */
    /* at the end, the Pos is set to the updated alignment */
    for(t=0;t<B->IP->nNumMotifTypes;t++)
      {
	Pos_t=Pos[t];
	for(i=0;i<B->IP->nSeqLen;i++)
	  {
	    Pos_t[i].nInMotif=FALSE;
	    Pos_t[i].nMotifStartPos=FALSE;
	    Pos_t[i].RevComp = 0;		/* BT 4/9/97 */
	  }
      }

    for(index=0, shift = -1 * maxleft; shift <= maxright; shift++) {
       /**************************************************/
       /* This loop iterates through all of the column   */
       /* shifts and stores the probatility for each one */
       /* the overlap is not checked, because all the    */
       /* segements shift the same                       */
       /**************************************************/

       tprob = 0.0;
       for(t = 0; t < B->IP->nNumMotifTypes; t++) {
          curr = M[t]->Motifs;
          dprob = 1.0;
          while(curr != NULL) {
              adjust_counts(B, DELETE, curr->pos, t ,curr->RevComp);
	      if(!curr->RevComp) {              /* Forward elements    */
                 if(shift != -1 *maxleft)       /* All shift in same   */
                    curr->pos -= (shift - 1);   /* Direction           */
                 curr->pos += shift;
              }
              else {
                 if(shift != -1 * maxleft)      /* Reverse Complements */
                    curr->pos += (shift - 1);   /* All shift in the    */
                 curr->pos -= shift;            /* opposite direction  */
              }
              adjust_counts(B, ADD, curr->pos, t, curr->RevComp);
#ifdef _DEBUG_
	      CheckCounts( B );
#endif
              update_prob(P, B, (! B->IP->is_defined[cl_b]) );
	      /*	      dprob *= in_motif_prob(B, *P, curr->pos, t, FALSE, FALSE);  */
	      if( (! B->IP->is_defined[cl_D]) || (curr->seq_num % 2 == 0) )
		dprob *= in_motif_prob(B, *P, curr->pos, t, curr->RevComp, 
				       TRUE, &dMotifProb, &dBGProb);   /* BT 2/9/98 */
              curr = curr->next;
          }  
          tprob += dprob;
       } 

       ProbArray[index] = tprob;
       totprob += ProbArray[index];
       index++;
    }
    for(index = 0; index <= maxleft + maxright; index++)  /* Normalize     */
        ProbArray[index] /= totprob;                      /* probabilities */

    tprob = 0;
    dprob = (double)Random()/(double)INT32_MAX;
    for(index = 0, FOUND = FALSE; ((!FOUND) && (index <= (maxleft+maxright))); 
        index++) {
        tprob += ProbArray[index];                       /* Randomly sample */
        if(dprob < tprob)                                /* the probability */
            FOUND = TRUE;
    }
    index--; 

    for(t = 0; t < B->IP->nNumMotifTypes; t++) {   /* the alignment     */
      curr = M[t]->Motifs;                         /* has been sampled  */
      B->IP->col_shift = -1 * maxleft + index;     /* so update the     */
      while(curr != NULL) {                        /* previous alignment*/
	adjust_counts(B, DELETE, curr->pos,t, curr->RevComp);
	if(!curr->RevComp) {                  /* Forward Motifs   */
	  curr->pos -= (maxright + maxleft);  /* go one direction */
	  curr->pos += index;
	}
	else {
	  curr->pos += (maxright + maxleft);  /* Reverse complements */
	  curr->pos -= index;                 /* go the other way    */
	}
	adjust_counts(B, ADD, curr->pos, t, curr->RevComp);
	/* the left and right shift are not adjusted */
	/* because the motif is still in the same sequence */

	/* copy the alignment to Pos */
	set_in_motif(Pos,curr->pos,B,t,curr->RevComp);
	curr = curr->next;
      }
    }
    update_prob(P, B, (! B->IP->is_defined[cl_b]));
    /*    set_posterior_prob( B->IP, B->C ); */  /* BT 8/11/97 */
    free(ProbArray);
}


