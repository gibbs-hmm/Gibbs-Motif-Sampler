/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/***************************************************************************/
/* $Id: motifsamp.old.c,v 1.4 2007/05/23 18:19:57 Bill Exp $                                                                  */
/* AUTHOR    : Eric C. Rouchka,  July 2, 1996                              */
/*             Jun Zhu,   October 20, 1996                                 */
/*                                                                         */
/***************************************************************************/

#include "motifsamp.h"


/*******************  sample_motif  ***************************************/
/* PARAMETERS :                                                           */
/*                                                                        */
/* DESCRIPTION :                                                          */
/*    Sampling motifs according to posterior probability distribution     */
/*    of elements in the model.                                           */
/*========================================================================*/

void sample_motif(Model B, PoSition **Pos, Mlist M, int iterations, 
		  int ****occurence, ProbStruct *P)

{
   double tprob, rand_num, rand_num2;
   int i,t, n;
   int tcount, count;
   short FOUND=FALSE;
   short RevComp;
   double sum, fwdprob, revprob;
   double **dFinalProb;

   /* dFinalProb[Motiftype][FORWARD/REVERSE] */
   /* dFinalProb is the probability that the segment derived from */
   /* the model motif */
   NEWP(dFinalProb, B->IP->nNumMotifTypes, double);
   for(t = 0; t < B->IP->nNumMotifTypes; t++)
      NEW(dFinalProb[t], 2, double);


   n=0;
   /* we should avoid to always sample from type 1 to N */
   count=0;
   while(n<B->IP->nSeqLen){
   
      rand_num = (double)Random()/(double)LONG_MAX;
      if( B->IP->RevComplement )
               rand_num += (double)Random()/(double)LONG_MAX; /* BT 4/11/97 */

      FOUND = FALSE;
      count=count%B->IP->nNumMotifTypes;
      for(tcount=count;(tcount<count+B->IP->nNumMotifTypes)&&!FOUND;tcount++){
	 tprob=0.0;
	 t=tcount%B->IP->nNumMotifTypes;
         dFinalProb[t][FORWARD] = 0.0;
         dFinalProb[t][REVERSE] = 0.0;
        
         if(PossFragStartPos(Pos, n, t, B) &&
	    !OverlapsPrevMotif(n,B->IP->nNumMotifTypes,Pos)){
            CheckMotifProb(B, n, t, Pos, P, M, &dFinalProb);
            tprob += dFinalProb[t][FORWARD]; /* Find the total prob that */
            if(B->IP->RevComplement)         /* a position begins here   */
               tprob += dFinalProb[t][REVERSE];
            if((tprob>0.0) && (rand_num<=tprob)) { /*Find which, if any of   */
               FOUND = TRUE;                       /* the motif types should */
               RevComp = FALSE;                    /* be sampled             */
               if(B->IP->RevComplement) {
                  sum = dFinalProb[t][FORWARD] + dFinalProb[t][REVERSE];
                  fwdprob = dFinalProb[t][FORWARD] / sum;
                  revprob = dFinalProb[t][REVERSE] / sum;
                  rand_num2 = (double)Random()/(double)LONG_MAX;
                  if(rand_num2 < revprob)
                     RevComp = TRUE;
               }
               (*occurence)[n][t][0]++;
               if(RevComp) { (*occurence)[n][t][2]++; }
               else        { (*occurence)[n][t][1]++; }
               P->update = TRUE;
	       adjust_counts(B,ADD,n,t,RevComp);
	       B->IP->nNumMotifs[t][RevComp]++;
               set_in_motif(Pos, n, B->IP->nMotifLen, t, RevComp);
 	       add_motif(B->Seq,n, M, t, RevComp);

               if(iterations > 3) {update_posterior_prob(B);}
	       /* skip the length of this motif */
	       n+=(B->IP->nMotifLen[t]-1); /* -1 here, because n will */
	                                  /* increase by 1 at the end*/
	                                  /* of for loop */
	       count++;
            }
         }
      }
    n++;
   }
   FREEP(dFinalProb, B->IP->nNumMotifTypes);
}

MaxResults nearopt_motif_samp(Model B, PoSition **Pos, Mlist M, int **good,  
                              ProbStruct *P, int ****occurence) 
{
   int i, n, t, last_increase;
   double dCurrProb, dLocMax, dMaxProbability=0.0;
   double **dProbArray;
   MaxResults currMax;
   int **posSave;			/* BT 3/26/97 */

   NEWP( posSave, B->IP->nNumMotifTypes, int);                /* BT 3/26/97 */
   for(i = 0; i < B->IP->nNumMotifTypes; i++)
      NEW( posSave[i], B->IP->nSeqLen, int);

   init_maxdata(&currMax);
   for(t = 0; t < B->IP->nNumMotifTypes; t++)
   {         
     for(n = 0; n < B->IP->nSeqLen; n++)
     {
       posSave[t][n] = Pos[t][n].nPossStartPos; 
       if(!good[n][t])
       {
	 Pos[t][n].nPossStartPos = FALSE;
       }
     }
   }

   FREEP(good, B->IP->nSeqLen);
   for(i = 1; i <= B->IP->nMaxIterations; i++) {
      if(i % 5 == 0)
         fprintf(stderr, "\r%d", i);
      sample_motif(B, Pos, M, i, occurence, P);
      for(dCurrProb = 0, t=0; t < B->IP->nNumMotifTypes; t++)
         dCurrProb += FindMapProb(B->C, B->IP, t);
      dCurrProb -= B->IP->dnull_map;
      if((dCurrProb > dLocMax) || (i == 1)) {
          printf("Max set %f at %d\n", dCurrProb, i);
          dProbArray = setElementProb(B, Pos, *P);
          free_maxdata(&currMax, B->IP);
          currMax = setMaxData(B->F, B->IP, dCurrProb, i, Pos, &last_increase,
                             &dMaxProbability, &dLocMax, currMax, dProbArray);
          FREEP(dProbArray, findMaxNumMotif(B->IP));
      }
   }

   /* Restore possible site starting positions for next phase */
   for(t = 0; t < B->IP->nNumMotifTypes; t++)		/* BT 3/26/97 */
   {         
     for(n = 0; n < B->IP->nSeqLen; n++)
       Pos[t][n].nPossStartPos = posSave[t][n]; 
   }
   FREEP( posSave, B->IP->nNumMotifTypes);

   return currMax;
}






