/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/****************************************************************/
/*                                                              */
/* $Header: /home/junzhu1/proj/RCS/Gibbs_GUI.c,v 1.2 1996/09/18 */
/* 18:44:26 junzhu Exp junzhu $                                 */
/*                                                              */
/* $Author: Bill $                                            */
/*	    Bill Thompson 1/24/97                               */
/* $Date: 2007/05/23 18:19:55 $                                 */
/* Description: graphic user interface for Gibbs                */
/*                                                              */
/****************************************************************/


#include "Gibbs_GUI.h"

/* external routines */
void GUI_win(Widget);

void Gibbs_GUI(int argc, char **argv)
{
  int          i;
  Widget       pw;        /* paned widget for contain all other widgets */
  Arg          wargs[20]; /* argument list */
  int          n;         /* argument register */
  char         string[80];
  char         colorname[80];
  char         ch;
  FILE         *fpt;
  XTextProperty  windowName,iconName; /* window name and icon name */
  char * icon_name ="GIBBS";
  char * window_name="GIBBS SAMPLER";

  XtToolkitInitialize();
  /* create an application context */
  app_context=XtCreateApplicationContext();

  if ((idispl = XtOpenDisplay(app_context, NULL, argv[0], 
              "GIBBS", NULL, 0, & argc, argv)) == NULL)
    { XtWarning("*** GIBBS can not open display! "); exit (-1); }
  toplevel = XtAppCreateShell(argv[0], "GIBBS", 
			      applicationShellWidgetClass, idispl, NULL, 0);  

  XtGetApplicationResources(toplevel, (char *)&fontdata, resources,
             XtNumber(resources), NULL, 0);  

  /* create a PanedWindow to contain all the widgets */
  n=0;
  XtSetArg(wargs[n], XmNwidth,  700);  n++; 
  XtSetArg(wargs[n], XmNheight, 700);  n++;
  pw=XtCreateWidget("board",xmFormWidgetClass,
                           toplevel,wargs,n);
  XtManageChild(pw);

  /* create child widgets */
  GUI_win(pw);

  /* allocate space for GUI_argv */
  NEWP(GUI_argv,MAX_ARG_SIZE,char);			/* BT 1/24/97 - changed size to match for loop */
  for(n=0;n<MAX_ARG_SIZE;n++)
    {
      NEW(GUI_argv[n],FILENAME_MAX,char);      /* BT 5/9/97 */
    }

  /* pop up the windows */
  XtRealizeWidget(toplevel);


  idispl=XtDisplay(toplevel);
  /* find default screen pointer */
  if((iscreen = DefaultScreenOfDisplay(idispl)) == 0)
    {XtWarning("*** Gibbs  can not determine screen!"); exit (-1);}

  /* find depth of screen (number of bit planes) */
  if((idepth = DefaultDepthOfScreen(iscreen)) < 8)
    {XtWarning("*** Screen depth is too shallow!"); exit (-1); }

  /* find root window pointer */
  iroot=RootWindowOfScreen(iscreen); 

  /* allocate color map */
  mapdef=DefaultColormap(idispl,DefaultScreen(idispl));
  /* allocate the cell for default colors defined in X11 directory */
  if((fpt=fopen(rgb_file,"r"))!=NULL)
     {
       i=0;
       while((ch=getc(fpt)) != (char) EOF)  /* BT 12/14/99 */
	 {
	   string[i]=ch;
	   while((ch=getc(fpt))!='\n')
	     {
	       i++;
	       string[i]=ch;
	     }
	   i=0;
	   sscanf(string,"%hd %hd %hd %s", &Colors[0].red,
		  &Colors[0].green,&Colors[0].blue,colorname);	   
	   XAllocNamedColor(idispl,mapdef,colorname,&Colors[0],&Colors[1]);
	 }
       fclose(fpt);       
     }
  else
    {
      fprintf( stdout, "Could not open \"%s\"!",rgb_file);
    }

  /* initiate individual color cell */
  for(i=0;i<=MAXCOLOR-1;i++)
    {
      Colors[i].pixel=i;
      Colors[i].flags=DoRed|DoGreen|DoBlue;
    }
  XQueryColors(idispl,mapdef,Colors,MAXCOLOR);
      
  /* set WM property for window's name and icon's name */
  iwtop=XtWindow(toplevel);
  XStringListToTextProperty(&icon_name,1,&iconName);
  XStringListToTextProperty(&window_name,1,&windowName);
  XSetWMName(idispl,iwtop,&windowName);
  XSetWMIconName(idispl,iwtop,&iconName);
  XtAppMainLoop(app_context);

  free(GUI_argv  );
}

 void quit()
 
 {
   exit(0);
 }

