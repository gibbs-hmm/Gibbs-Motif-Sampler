/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/***********************************************************************/
/* $Header:                                                            */
/*                                                                     */
/* $Author: Jun Zhu                                                    */
/* $Date:                                                              */
/* $Description: Create child widgets of Panewindow                    */
/*               All the widgets in the main window are created        */
/*               menubar(XmMenuBar):                                   */
/*	            at the top of main window to contain all the menu  */
/*                  and submenu                                        */
/*               iw_message(XmScrolledText):                           */
/*                  at the bottom of the main window to give dialog or */
/*                  warning messages                                   */
/*		 canvas(XmDrawingArea):                                */
/*                  at the center of the main window. It is the working*/
/* 		    area for drawing data flow graph                   */
/*                                                                     */
/***********************************************************************/

#include "perror.h"
#include "GUI_common.h"
#include <Xm/RowColumn.h>
#include <Xm/Text.h>
#include <Xm/ScrollBar.h>
#include <Xm/DrawingA.h>
#include <Xm/Separator.h>

/* global widgets defined here*/
Widget canvas;          /* drawing area widget  */
Widget iw_message;      /* message Widget       */

/* routines used */
void GUI_com(Widget);
void QuitRoutine(Widget iw_temp, caddr_t data, caddr_t call_data);  /* BT 6/17/97 */
void OKRoutine(Widget iw_temp, caddr_t data, caddr_t call_data);    
void CancelRoutine(Widget iw_temp, caddr_t data, caddr_t call_data);

void GUI_win(Widget pw)
{
  /*  Widget       menubar; */   /* menubar to contain all the buttons */
  Arg          wargs[20]; /* argument list */
  int          n;         /* argument register */
  Widget       sep;       /* BT 7/8/97 */

/* create a menubar to contain buttons */
  n = 0;
  XtSetArg(wargs[n], XmNtopAttachment,  XmATTACH_FORM);  n++;
  XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_FORM);  n++;
  XtSetArg(wargs[n], XmNrightAttachment,XmATTACH_FORM);  n++;
  menubar =XmCreateMenuBar(pw, "menubar", wargs, n); 

/* create menu buttons */
  GUI_com(menubar); 

  XtManageChild(menubar);

/* create a message Widget */
  n=0;
  XtSetArg(wargs[n], XmNscrollingPolicy,    XmAUTOMATIC);       n++;
  XtSetArg(wargs[n], XmNscrollBarDisplayPolicy, XmSTATIC);      n++;
  XtSetArg(wargs[n], XmNscrollBarPlacement, XmBOTTOM_RIGHT);    n++;
  XtSetArg(wargs[n], XmNvisualPolicy,       XmCONSTANT);        n++;
  XtSetArg(wargs[n], XmNeditMode,           XmMULTI_LINE_EDIT); n++;
  XtSetArg(wargs[n], XmNeditable,           False);             n++;
  XtSetArg(wargs[n], XmNleftAttachment,     XmATTACH_FORM);     n++;
  XtSetArg(wargs[n], XmNrightAttachment,    XmATTACH_FORM);     n++; 
  XtSetArg(wargs[n], XmNbottomAttachment,   XmATTACH_FORM);     n++;
  XtSetArg(wargs[n], XmNheight,             90);                n++;
  XtSetArg(wargs[n], XmNtraversalOn,   False);        n++; 
  iw_message = XmCreateScrolledText(pw, "message", wargs, n);
  XtManageChild(iw_message);

/* print out first message */
   message("Gibbs>\n");

  /* BT 6/17/97 */
  stopButton = wid_pushg( pw, 0 ,"   Halt  ",
			  QuitRoutine ,NULL, 0, 15 );

  n = 0;
  XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_WIDGET); n++;
  XtSetArg(wargs[n], XmNtopWidget, menubar); n++;
  XtSetArg(wargs[n], XmNbottomAttachment, XmATTACH_NONE); n++;
  XtSetValues(stopButton, wargs, n);

  n = 0;
  XtSetArg(wargs[n], XmNx, 0);             n++;
  XtSetArg(wargs[n], XmNy, 15);            n++;
  sep = XmCreateSeparator( pw, "sep", wargs, n );       /*BT 7/9/97 */
  XtManageChild(sep);

  n = 0;
  XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_WIDGET); n++;
  XtSetArg(wargs[n], XmNtopWidget, stopButton); n++;
  XtSetArg(wargs[n], XmNrightAttachment, XmATTACH_FORM); n++;
  XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_FORM); n++;
  XtSetArg(wargs[n], XmNbottomAttachment, XmATTACH_NONE); n++;
  XtSetValues(sep, wargs, n);

/*
* Create a widget in which to display image.
*/

  n = 0;
  /*  XtSetArg(wargs[n], XmNtopWidget,        menubar);            n++; */
  XtSetArg(wargs[n], XmNtopWidget,        sep);            n++;
  XtSetArg(wargs[n], XmNtopAttachment,    XmATTACH_WIDGET);    n++;
  XtSetArg(wargs[n], XmNbottomWidget,     iw_message);         n++;
  XtSetArg(wargs[n], XmNbottomAttachment, XmATTACH_WIDGET);    n++;
  XtSetArg(wargs[n], XmNleftAttachment,   XmATTACH_FORM);      n++;
  XtSetArg(wargs[n], XmNrightAttachment,  XmATTACH_FORM);      n++;

  canvas = XtCreateWidget("canvas", xmDrawingAreaWidgetClass, 
                         pw, wargs, n);
  XtManageChild(canvas); 
}


/* BT 6/17/97 */
void QuitRoutine(Widget iw_temp, caddr_t data, caddr_t call_data)
{
  char   tmpstr[128];
  Widget iw_msg;
  char    answer = 0;

  strcpy( tmpstr, "Exit Gibbs?" );
  iw_msg = wid_message( (Widget) toplevel, (Widget) 0, tmpstr, OKRoutine, NULL, CancelRoutine, &answer, 0, 0 );
  while( answer == 0 )
    XtAppProcessEvent( app_context, XtIMAll ); 
}

 
void OKRoutine(Widget iw_temp, caddr_t data, caddr_t call_data)
{
  p_error( "User requested exit." );
}


void CancelRoutine(Widget iw_temp, caddr_t data, caddr_t call_data)
{
  char *answer = (char *) data;

  *data = 1;
}
