/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/**************************************************************************/
/*                                                                        */
/* $Id: GUI_Sankoff.c,v 1.4 2007/05/23 18:19:55 Bill Exp $       */
/*                                                                        */
/* Author: junzhu 1996/7/15                                               */
/* Description: Create GUI for Sankoff algorithm                          */
/**************************************************************************/

#include "GUI_common.h"
#include <Xm/Text.h>
#include <Xm/ToggleBG.h>
#include "common.h"                             
#include "parameters.h"             
#include "printdata.h"
#include "counts.h"
#include "probability.h"
#include "sampling.h"
#include "process.h"
#include "Sankoff.h"
#include "mem_mgmt.h"

#define MAX_BLOCKS 10
#define MAX_NUM_MATRIX 8

/* file scope variables */
    Widget        iw_Sankoff = (Widget)0;
    Widget        iws_rowcol;        /* rowcol to contain buttons */
    Widget        iws_label;         /* label for function */
    Widget        buts_stop;         /* button for stop    */
    Widget        buts_accept;       /* button for accept  */
    Widget        iws_inputfile;     /* for input file     */
    Widget        iws_blocks;        /* for number of blocks */
    Widget        iws_outfile;       /* for output file    */
    Widget        iws_outfile_name;  /* for output file    */
    Widget        iws_output_sequence;/* for output sequence    */
    Widget        iws_best_alignment; /* flag may turn off best alingment */
    Widget        iws_backsampling;  /* flag for backsampling */
    Widget        iws_backsampling_blocks;
    Widget        iws_backsampling_number;
    Widget        iws_backsampling_sequence;
    Widget        iws_backsampling_cutoff;
    Widget        iws_backsampling_cutoff_value;
    int           Sankoff_matrix_num;

    static char*  s_inputfile=" ";   /* input file name    */

/* routine define here */
void GUI_Sankoff_accept(Widget, caddr_t, caddr_t);
void GUI_Sankoff_toggle(Widget parent, void *data, void *call_data);  /* BT 12/9/99 */
void GUI_Sankoff_stop(Widget, caddr_t, caddr_t);
void GUI_Sankoff_option_menu(Widget parent, void *data, void *call_data);

/********************   GUI_Sankoff   ******************************/

void GUI_Sankoff(Widget iw_temp, caddr_t data, caddr_t call_data)
{

    Widget rowcol_tmp;   /* tmp row_col widget */
    Widget option_menu;
    char cval[50];

    /* create a menu widget first */        
    iw_Sankoff = wid_dialog(canvas,iw_Sankoff,"Sankoff sampler",
                                 30,30);
    if(iws_rowcol!=(Widget)0)
      XtUnmanageChild(iws_rowcol);
    iws_rowcol   = wid_rowcol(iw_Sankoff ,'v',-1,-1);
    iws_label=wid_labelg(iws_rowcol,0,"Sankoff Sampler",0,0);

    /* widget for input file */
    rowcol_tmp=wid_rowcol(iws_rowcol,'h',-1,-1); 
    sprintf(cval,"%s",s_inputfile);
    iws_inputfile=wid_textboxb(rowcol_tmp,0,"Input data file:",cval,50); 

    /* maximum number of blocks and relation matrix */
    rowcol_tmp=wid_rowcol(iws_rowcol,'h',-1,-1);
    sprintf(cval,"%d",MAX_BLOCKS);
    iws_blocks=wid_textboxb(rowcol_tmp,0,"Maximum blocks number:",
				    cval,10);

    Sankoff_matrix_num=5; 
    option_menu=XmVaCreateSimpleOptionMenu(rowcol_tmp,"option_menu",
	   XmStringCreateLocalized("Relation matrix:"),'R',Sankoff_matrix_num,
					        GUI_Sankoff_option_menu,
	   XmVaPUSHBUTTON,XmStringCreateLocalized("Blosum30"),' ',NULL,NULL,
	   XmVaPUSHBUTTON,XmStringCreateLocalized("Blosum35"),' ',NULL,NULL,
	   XmVaPUSHBUTTON,XmStringCreateLocalized("Blosum40"),' ',NULL,NULL,
	   XmVaPUSHBUTTON,XmStringCreateLocalized("Blosum45"),' ',NULL,NULL,
	   XmVaPUSHBUTTON,XmStringCreateLocalized("Blosum50"),' ',NULL,NULL,
	   XmVaPUSHBUTTON,XmStringCreateLocalized("Blosum62"),' ',NULL,NULL,
	   XmVaPUSHBUTTON,XmStringCreateLocalized("Blosum80"),' ',NULL,NULL,
	   XmVaPUSHBUTTON,XmStringCreateLocalized("Blosum100"),' ',NULL,NULL,
	   XmVaPUSHBUTTON,XmStringCreateLocalized("All ABOVE"),' ',NULL,NULL,
	   NULL);
    XtManageChild(option_menu);


    /* output file */
    rowcol_tmp=wid_rowcol(iws_rowcol,'h',-1,-1);
    iws_outfile=wid_toggleg(rowcol_tmp,0,
			"Output file?",FALSE,
			GUI_Sankoff_toggle,NULL,-1,-1);
     sprintf(cval,"%s"," ");
     iws_outfile_name=wid_textboxb(rowcol_tmp,0,
				  "Output file name:",cval,30);  
     XtUnmanageChild(XtParent(iws_outfile_name));
     XtRemoveAllCallbacks(iws_outfile, XmNvalueChangedCallback);
     XtAddCallback(iws_outfile,XmNvalueChangedCallback,
		   GUI_Sankoff_toggle,iws_outfile_name);

    rowcol_tmp=wid_rowcol(iws_rowcol,'h',-1,-1);
    iws_best_alignment=wid_toggleg(rowcol_tmp,0,
				    "Best alignment?",TRUE,
				    GUI_Sankoff_toggle,NULL,-1,-1);
    iws_output_sequence=wid_toggleg(rowcol_tmp,0,
				    "Output matching sequence?",FALSE,
				    GUI_Sankoff_toggle,NULL,-1,-1);

    /* back sampling */
    rowcol_tmp=wid_rowcol(iws_rowcol,'h',-1,-1);
    iws_backsampling=wid_toggleg(rowcol_tmp,0,
			"back sampling?",FALSE,
			GUI_Sankoff_toggle,NULL,-1,-1);
     sprintf(cval,"%s"," ");
     iws_backsampling_blocks=wid_textboxb(rowcol_tmp,0,
				  "Num. of  blocks:",cval,5);  
     XtUnmanageChild(XtParent(iws_backsampling_blocks)); 
     iws_backsampling_number=wid_textboxb(rowcol_tmp,0,
				  "Num. of sequence:",cval,5);  
     XtUnmanageChild(XtParent(iws_backsampling_number));

     rowcol_tmp=wid_rowcol(iws_rowcol,'h',-1,-1);
     iws_backsampling_sequence=wid_toggleg(rowcol_tmp,0,
			"Output sampling sequence?",FALSE,
			GUI_Sankoff_toggle,NULL,-1,-1);
     XtUnmanageChild(XtParent(iws_backsampling_sequence));

     /* trace back all the alignment above a cutoff */
     rowcol_tmp=wid_rowcol(iws_rowcol,'h',-1,-1);
     iws_backsampling_cutoff=wid_toggleg(rowcol_tmp,0,
			"Find all alignment above a cutoff?",FALSE,
			GUI_Sankoff_toggle,NULL,-1,-1);
     sprintf(cval,"%s"," ");
     iws_backsampling_cutoff_value=wid_textboxb(rowcol_tmp,0,
				  "Cutoff value:",cval,5);  
     XtUnmanageChild(XtParent(iws_backsampling_cutoff_value)); 

     XtRemoveAllCallbacks(iws_backsampling_cutoff, XmNvalueChangedCallback);
     XtAddCallback(iws_backsampling_cutoff,XmNvalueChangedCallback,
		   GUI_Sankoff_toggle,iws_backsampling_cutoff_value);
     XtUnmanageChild(XtParent(iws_backsampling_cutoff));


     XtRemoveAllCallbacks(iws_backsampling, XmNvalueChangedCallback);
     XtAddCallback(iws_backsampling,XmNvalueChangedCallback,
		   GUI_Sankoff_toggle,iws_backsampling_blocks);
     XtAddCallback(iws_backsampling,XmNvalueChangedCallback,
		   GUI_Sankoff_toggle,iws_backsampling_number);
     XtAddCallback(iws_backsampling,XmNvalueChangedCallback,
		   GUI_Sankoff_toggle,iws_backsampling_sequence);
     XtAddCallback(iws_backsampling,XmNvalueChangedCallback,
		   GUI_Sankoff_toggle,iws_backsampling_cutoff);


    /* button for stop and accept */
    rowcol_tmp=wid_rowcol(iws_rowcol,'h',-1,-1); 
    buts_stop=wid_pushg(rowcol_tmp,0,"   Stop  ",
                         GUI_Sankoff_stop,NULL,0,0);
    buts_accept=wid_pushg(rowcol_tmp,0,"  Accept  ",
                         GUI_Sankoff_accept,NULL,0,0);

    XtManageChild(iw_Sankoff);
}

/************ accept button callback *********************************/

void GUI_Sankoff_accept(Widget iw_temp, caddr_t data, caddr_t call_data)
{
  Model M;
  Sank_S SK;
  int i;
  int backsampling, backsampling_blocks,backsampling_number;
  int backsampling_cutoff;
  float backsampling_cutoff_value;
  int Sankoff_blocks;
  int val;
  char *cval;
  char *outputfile;
  FILE *fptr;

  /* input data file */
  s_inputfile=XmTextGetString(iws_inputfile);
  GUI_strip_space(s_inputfile);
  if((fptr=fopen(s_inputfile,"r"))==NULL)
    {
      wid_error(iw_Sankoff,0,"Check input file name!!!",0,0);
      return;
    }
  /* check Maximum Number of Blocks */
  cval=XmTextGetString(iws_blocks);
  GUI_strip_space(cval); 
  if(sscanf(cval,"%d", &Sankoff_blocks)!= 1)
  { 
      wid_error(iw_Sankoff,0,"Check input maximum number of matching blocks",
		0,0);
      return;        
  }    

  /* check back sampling */
  if(XmToggleButtonGadgetGetState(iws_backsampling))
    {
      backsampling=TRUE;

      /* check number of max blocks for back sampling */
      cval=XmTextGetString(iws_backsampling_blocks);
      GUI_strip_space(cval); 
      if(sscanf(cval,"%d", &backsampling_blocks)!= 1)
	{ 
	  wid_error(iw_Sankoff,0,
		    "Check maximum number of back sampling blocks",0,0);
	  return;        
	}    
      /* if (backsamplig >Sankoff_blocks), sampling with random blocks */
      /* less than Sankoff_blocks */
      if(backsampling <=0)
	{
	  wid_error(iw_Sankoff,0,
		    "Check maximum number of back sampling blocks",0,0);
	  return;        
	}    	  

      /* check number of sequence for back sampling */
      cval=XmTextGetString(iws_backsampling_number);
      GUI_strip_space(cval); 
      if(sscanf(cval,"%d", &backsampling_number)!= 1)
	{ 
	  wid_error(iw_Sankoff,0,
		    "Check number of sequence for back sampling!!",0,0);
	  return;        
	}    
      /* check trace back all alignment above a cutoff */
      if(XmToggleButtonGadgetGetState(iws_backsampling_cutoff))
	{
	  backsampling_cutoff=TRUE;
	  cval=XmTextGetString(iws_backsampling_cutoff_value);
	  GUI_strip_space(cval); 
	  if(sscanf(cval,"%f", &backsampling_cutoff_value)!= 1)
	    { 
	      wid_error(iw_Sankoff,0,
			"Check cutoff value for back sampling!!",0,0);
	      return;        
	    } 
	}
      else
	backsampling_cutoff=FALSE;
    }
  else
      backsampling=FALSE;

  M = alloc_Model();
  NEW(M->IP->Datafiles,1,files);
  M->IP->Datafiles->fpt=fptr;
  M->IP->Datafiles->filename=(char *)malloc(strlen(s_inputfile)*sizeof(char));
  strcpy(M->IP->Datafiles->filename,s_inputfile);
  M->IP->nAlphaLen=20;                       /* protein sequence */

  /* output file */
  if(XmToggleButtonGadgetGetState(iws_outfile))
    {
      outputfile=XmTextGetString(iws_outfile_name);
      GUI_strip_space(outputfile);
      M->IP->Datafiles->out_fpt=fopen(outputfile,"w");
      if(M->IP->Datafiles->out_fpt==NULL) M->IP->Datafiles->out_fpt=stdout;
    }
  else
    M->IP->Datafiles->out_fpt=stdout;

  get_strings(M);                /* Read the sequences */  

  SK=(Sank_S)malloc(sizeof(Sankoff_struct));

  /* relation matrix */
  SK->matrix_num=Sankoff_matrix_num;
  if(Sankoff_matrix_num==MAX_NUM_MATRIX)
      SK->Nmatrix=MAX_NUM_MATRIX;
  else
      SK->Nmatrix=1;    

  /* Maximum Number of Blocks */
  SK->Sankoff_blocks=Sankoff_blocks;
 

  /* flags for best alignment and output alignment sequences */
  if(XmToggleButtonGadgetGetState(iws_best_alignment)){
      SK->flags.best_alignment=TRUE;
  }
  else{
      SK->flags.best_alignment=FALSE;
  }
  if(XmToggleButtonGadgetGetState(iws_output_sequence)){
      SK->flags.output_sequence=TRUE;
  }
  else{
      SK->flags.output_sequence=FALSE;
  }

  /* back sampling */
  SK->flags.back_sampling=backsampling;
  if(SK->flags.back_sampling)
    {
      SK->backsampling_blocks=backsampling_blocks;
      SK->backsampling_number=backsampling_number;
      if(XmToggleButtonGadgetGetState(iws_backsampling_sequence))
	{
	  SK->flags.back_sampling_sequence=TRUE;
	}
      else
	{
	  SK->flags.back_sampling_sequence=FALSE;
	}
      if((SK->flags.back_sampling_cutoff=backsampling_cutoff))
	SK->backsampling_cutoff_value=backsampling_cutoff_value;      
    }

  XtUnmanageChild(iw_Sankoff);
  XFlush(idispl);

  Sankoff(M,SK);

}


/*************** option menu call back *******************************/
void GUI_Sankoff_option_menu(Widget parent, void *data, void *call_data)
{

  Sankoff_matrix_num=(int)data;

}


/*************** toggle button click *********************************/
void GUI_Sankoff_toggle(Widget parent, void *data, void *call_data)  /* BT 12/9/99 */
{
  Widget tmp=(Widget) data;

  if(tmp!=NULL)
    {
      if(XmToggleButtonGadgetGetState(parent))
	{
	  /* pop up the following widget */
	  XtManageChild(XtParent(tmp));
	}
      else
	{
	  /* pop down the following widget */
	  XtUnmanageChild(XtParent(tmp));
	}
    }
}

/************ stop button callback *********************************/

void GUI_Sankoff_stop(Widget iw_temp, caddr_t data, caddr_t call_data)
{
      XtUnmanageChild(iw_Sankoff);  
}








