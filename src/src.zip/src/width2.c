/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/**************************************************************************/
/* $Id: width2.c,v 1.4 2007/05/23 18:19:58 Bill Exp $          */
/*                                                                        */
/* Author :       Bill Thompson 5/9/97                                    */
/*                                                                        */
/* Description :  This file contains the functions which are used to find */
/*                the best motif width. These routines are based on notes */
/*                Jun Liu 3/5/97                                          */
/*                                                                        */
/**************************************************************************/

#include <math.h>
#include <limits.h>
#include "width.h"
#include "probability.h"

#define LEFT    0
#define RIGHT   1

void CalcWidthProb( Model B, PoSition **Pos, Mlist M, double ***dWidthProb );
short PossibleWidth( int w, int t, Model B, PoSition **Pos, Mlist M, int dir, int oldLen );
short PossibleMotifWidth( int w, int t, Model B, PoSition **Pos, MlistEl *pMotif, 
			  int dir, int oldLen );
short PossibleOverlap( Model B, int curPos, int w, int dir, Mlist M,  MlistEl *pCurMotif, int oldLen );
short CheckPossibleOverlap( Model B, int curPos, int w, int dir, Mlist M,  
			    MlistEl *pCurMotif, int oldLen );
void CheckPossibleOverlapRight( Model B, int curPos, int w, int dir, Mlist M,  
				MlistEl *pCurMotif, MlistEl *pMotif, int oldLen,
				int t );
void ResetLengths( int w, int t, Model B, PoSition **Pos, Mlist M, int dir, int oldLen );
void CopyMotifs( int t, Model B, Mlist M, Mlist M2 );
void CopyTheMotif( MlistEl *pMotif, int t, Model B, Mlist M, Mlist M2 );
void ReleaseMotifs( int t, Mlist M2 );
void ResetGoodPosition( int t, Model B, PoSition **Pos, Mlist M );
void DumpCounts( Model B, int t );
void DumpMotifs( Model B, Mlist M );
void DumpPositions( int t, Model B, PoSition **Pos );
int GetMaxMotifWidth( Model B );
double factrl( int n );
double ln_factrl( int n );



void ResizeMotif( Model B, PoSition **Pos, Mlist M )
{
  int    i;
  int    t;
  IPtype IP;
  Ctype  C;
  double ***dWidthProb;

  IP= B->IP;
  C = B->C;

  NEWPP( dWidthProb, IP->nNumMotifTypes, double );
  for( t= 0; t < IP->nNumMotifTypes; t++ )
    {
      NEWP( dWidthProb[t], 2, double );
      for( i = 0; i < 2; i++ )
	{
	  NEW( dWidthProb[t][i], IP->nMaxMotifLen[t] + 1, double );
	}
    }
  
  CalcWidthProb( B, Pos, M, dWidthProb ); 

  for( t= 0; t < IP->nNumMotifTypes; t++ )
    {
      for( i = 0; i < 2; i++ )
	free( dWidthProb[t][i] );
      free( dWidthProb[t] );
    }
  free( dWidthProb );
}


void CalcWidthProb( Model B, PoSition **Pos, Mlist M, double ***dWidthProb )
{
  IPtype  IP;
  Ctype   C;
  int     t;
  int     i;
  int     j;
  int     w; 
  int     col;
  MlistEl *pMotif;
  double  dProb;
  int     oldLen;
  double  dTot;
  double  rnd;
  short   bFoundit;
  int     maxLen;
  int     minLen;
  int     dir;
  double  minProb;
  double  dSum;
  short   bCantAdjust;
  int      **nNumMotifs;
  double  dProb2;
  double  dProb3;
  int     len; 
  double  pw;
  double  ***dMap;
  Mlist   M2;
  int     nMotifCnt[2];

  IP= B->IP;
  C = B->C;

  NEWPP( dMap, IP->nNumMotifTypes, double );
  for( t = 0; t < IP->nNumMotifTypes; t++ )
    {
      NEWP( dMap[t], 2, double );
      for( dir = LEFT; dir <= RIGHT; dir++ )
        NEW( dMap[t][dir], IP->nMaxMotifLen[t] + 1, double );
    }

  NEWP( M2, IP->nNumMotifTypes, Mlist_struct );
  for( t = 0; t < IP->nNumMotifTypes; t++ )
    {
      NEW( M2[t], 1, Mlist_struct );
      M2[t]->Motifs = NULL;
      M2[t]->nNumMotifs = 0;
    }
  
  for( t = 0; t < IP->nNumMotifTypes; t++ )
    {
      DumpPositions( t, B, Pos );       /* Debug */

      oldLen = IP->nMotifLen[t];
      nMotifCnt[FORWARD] = IP->nNumMotifs[t][FORWARD];
      nMotifCnt[REVERSE] = IP->nNumMotifs[t][REVERSE];
      bFoundit = FALSE;
      minLen = IP->nMinMotifLen[t];
      maxLen = IP->nMaxMotifLen[t];
      dir = RIGHT;

      pw = log( IP->nMaxMotifLen[t] - IP->nMinMotifLen[t] + 1 );    /* p(w) */

      minProb = DBL_MAX;
      set_posterior_prob(IP, C);
      fprintf( stdout, "Motifs: %d Current Map = %10f Null = %10f MAP = %10f\n", 
	       NUMMOTIFS( IP->nNumMotifs[t] ),
	       FindMapProb( B->C, IP, t ), IP->dnull_map,
	       FindMapProb( B->C, IP, t ) - IP->dnull_map );

      pMotif = M[t]->Motifs;
      while( pMotif != NULL )               /* remove old motif counts */
	{
	  adjust_counts( B, DELETE, pMotif->pos, t, pMotif->RevComp );
	  pMotif = pMotif->next;
	}
      
      if( IP->nNumMotifs[t][FORWARD] == 18 &&
	  IP->nNumMotifs[t][REVERSE] == 26 )
	IP = IP;                                    /* Debug */

      for( w = minLen; w <= maxLen; w++ )
	{
	  for( dir = LEFT; dir <= RIGHT; dir++ )
	    {
	      if( (w == oldLen) && (dir == RIGHT) )    /* Don't want to give old length 2 chances */
		break;
	      IP->nMotifLen[t] = oldLen;
	      IP->nNumMotifs[t][FORWARD] = nMotifCnt[FORWARD];
	      IP->nNumMotifs[t][REVERSE]= nMotifCnt[REVERSE];
	      CopyMotifs( t, B, M, M2 );

	      if( PossibleWidth( w, t, B, Pos, M2, dir, oldLen ) )
		{
		  IP->nMotifLen[t] = w;
		  col = w;
		  pMotif = M2[t]->Motifs;
		  while( pMotif != NULL )
		    {
		      if( (dir == RIGHT && !pMotif->RevComp) ||
			  (dir == LEFT && pMotif->RevComp))
			adjust_counts( B, ADD, pMotif->pos, t, pMotif->RevComp );
		      else
			adjust_counts( B, ADD, pMotif->pos - (w - oldLen), t, pMotif->RevComp );
		      pMotif = pMotif->next;
		    }

		  SetPossibleSites( B, t );
		  set_posterior_prob(IP, C);
		  dMap[t][dir][w] = FindMapProb( B->C, IP, t );
		  dProb2 = dMap[t][dir][w] - pw;
		  if( IP->site_samp )
		    {
		      for( i = 0; i < IP->nNumSequences; i++ )
			{
			  if( i == 0 )
			    len = (*B->Seq->nvEndLocs)[i];
			  else
			    len = (*B->Seq->nvEndLocs)[i] - (*B->Seq->nvEndLocs)[i - 1];
			  dProb2 -= log(len - w);
			}  
		    }
		  else
		    {
		      dProb3 = ln_factrl(  NUMMOTIFS( IP->nNumMotifs[t] ) );
		      for( i = 0; i <  NUMMOTIFS( IP->nNumMotifs[t] ); i++ )
			{
			  dProb3 -= log( IP->nPossSites[t] - i *w );
			  if( ! finite( dProb3 ) ||  (IP->nPossSites[t] - i * w == 0) )
			    DumpMotifs( B, M );
			}
		      dProb2 += dProb3;
		    }


		  dWidthProb[t][dir][w] = dProb2;
		  if( dWidthProb[t][dir][w] < minProb )
		    minProb = dWidthProb[t][dir][w];

		  pMotif = M2[t]->Motifs;
		  while( pMotif != NULL )
		    {
		      if( (dir == RIGHT && !pMotif->RevComp) ||
			  (dir == LEFT && pMotif->RevComp))
			adjust_counts( B, DELETE, pMotif->pos, t, pMotif->RevComp );
		      else
			adjust_counts( B, DELETE, pMotif->pos - (w - oldLen), t, pMotif->RevComp );
		      pMotif = pMotif->next;
		    }
		}
	    }
	}

      IP->nMotifLen[t] = oldLen;
      IP->nNumMotifs[t][FORWARD] = nMotifCnt[FORWARD];
      IP->nNumMotifs[t][REVERSE] = nMotifCnt[REVERSE];

      for( dTot = 0.0, w = minLen; w <= maxLen; w++ )
	{
	  if( minProb < 0.0 )
	    {
	      dWidthProb[t][LEFT][w] -= (dWidthProb[t][LEFT][w] == 0.0 ? 0.0 : 1.0) * (minProb - 1);
	      dWidthProb[t][RIGHT][w] -= (dWidthProb[t][RIGHT][w] == 0.0 ? 0.0 : 1.0) * (minProb - 1);
	    } 
	  dTot += dWidthProb[t][LEFT][w] + dWidthProb[t][RIGHT][w]; 
	}

      fprintf( stdout, "\n" );
      for( dSum = 0.0, w = minLen; w <= maxLen; w++ )
	{
	  if( dWidthProb[t][LEFT][w] != 0 || dWidthProb[t][RIGHT][w] != 0 )
	    fprintf( stdout, "%3d %3d %10f %10f %10f %10f %10f %10f\n", t, w, dWidthProb[t][LEFT][w], 
		     dWidthProb[t][RIGHT][w], 
		     dWidthProb[t][LEFT][w] / dTot, dWidthProb[t][RIGHT][w] / dTot,
		     dMap[t][LEFT][w] - IP->dnull_map, dMap[t][RIGHT][w] - IP->dnull_map );
	  dSum += dWidthProb[t][LEFT][w] / dTot + dWidthProb[t][RIGHT][w] / dTot;
	}
      fprintf( stdout, "%f\n", dSum ); 

    if( dTot > 0.0 )
	{ 
	  dProb = 0;
	  rnd = drand();
	  for( bFoundit = FALSE, dir = LEFT; dir <= RIGHT && !bFoundit; dir++ )
	    {
	      for( w = minLen; w <= maxLen && !bFoundit; w++ )
		{
		  dProb += dWidthProb[t][dir][w] / dTot;
		  if( dProb > rnd )
		    {
		      ResetLengths( w, t, B, Pos, M, dir, oldLen );
		      bFoundit = TRUE;
		      break;
		    }
		}
	    }
	  if( ! bFoundit )
	    ResetLengths( oldLen, t, B, Pos, M, RIGHT, oldLen );
	}
      else
	ResetLengths( oldLen, t, B, Pos, M, RIGHT, oldLen );
    }
  
  copy_counts( B );
  nNumMotifs = copy_motif_num(IP);
  zero_motifs(IP); /* set motif count to zero */
  
  /* calculate the probability of NULL model */
  for(IP->dnull_map = 0.0, t = 0; t <IP->nNumMotifTypes; t++)
    {
      SetPossibleSites( B, t );
      set_posterior_prob(IP, C);
      IP->dnull_map += FindMapProb(B->C,IP, t);
    }
  reset_motif_num(nNumMotifs,IP);

  for( t = 0; t < IP->nNumMotifTypes; t++ )
    {
      pMotif = M[t]->Motifs;
      while( pMotif != NULL )
	{
	  adjust_counts( B, ADD, pMotif->pos, t, pMotif->RevComp );
	  pMotif = pMotif->next;
	}
    }

  set_posterior_prob(IP, C);
  for( dProb = 0.0, t = 0; t < IP->nNumMotifTypes; t++ )
    dProb += FindMapProb( B->C, IP, t );
  dProb -= IP->dnull_map;
  
  fprintf( stdout, "MAP = %f rnd = %f\n", dProb, rnd );

  for( t= 0; t < IP->nNumMotifTypes; t++ )
    {
      for( dir = LEFT; dir <= RIGHT; dir++ )
	free( dMap[t][dir] );
      free( dMap[t] );
    }
  free( dMap );

  free_motifs( B, M2 );
  free( M2 );

  FREEP(nNumMotifs, IP->nNumMotifTypes);
  free(nNumMotifs);
}


short PossibleWidth( int w, int t, Model B, PoSition **Pos, Mlist M, int dir, int oldLen )
{
  IPtype  IP;
  MlistEl *pMotif;
  MlistEl *pCurMotif;

  IP = B->IP;
  pMotif = M[t]->Motifs;
  while( pMotif != NULL )
    {
      if( (dir == RIGHT && !pMotif->RevComp) ||
	  (dir == LEFT && pMotif->RevComp))
	{
	  if(/* pMotif->pos + w - 1 > pMotif->right || */
	     pMotif->pos + w >= IP->nSeqLen || 
	      /* Pos[t][pMotif->pos].nSeq != Pos[t][pMotif->pos + w - 1].nSeq  ||
		 PossibleOverlap( B, pMotif->pos, w, dir, M,  pMotif, oldLen ) */
	     Pos[t][pMotif->pos].nSeq != Pos[t][pMotif->pos + w - 1].nSeq )
	    {
	      B->IP->nNumMotifs[t][pMotif->RevComp ? REVERSE : FORWARD]--;
	      pCurMotif = pMotif;
	      pMotif = pMotif->next;
	      delete_motif( B, pCurMotif->pos, M, t);
	    }
	  else
	    {
	      CheckPossibleOverlap( B, pMotif->pos, w, dir, M,  pMotif, oldLen );
	      pMotif = pMotif->next;
	    }
	}
      else
	{
	  if( /* pMotif->pos - (w - oldLen) < pMotif->left || */
	     pMotif->pos - (w - oldLen) < 0 || 
	     pMotif->pos - (w - oldLen) >= IP->nSeqLen || 
	     Pos[t][pMotif->pos].nSeq != Pos[t][pMotif->pos - (w - oldLen)].nSeq )
	    {
	      B->IP->nNumMotifs[t][pMotif->RevComp ? REVERSE : FORWARD]--;
	      pCurMotif = pMotif;
	      pMotif = pMotif->next;
	      delete_motif( B, pCurMotif->pos, M, t);
	    }
	  else
	    {
	      CheckPossibleOverlap( B, pMotif->pos, w, dir, M,  pMotif, oldLen );
	      pMotif = pMotif->next;
	    }
	}
    }

  return TRUE;
}


short PossibleOverlap( Model B, int curPos, int w, int dir, Mlist M,  MlistEl *pCurMotif, int oldLen )
{
  IPtype   IP;
  int      t;
  MlistEl  *pMotif;

  IP = B->IP;

  for( t = 0; t < IP->nNumMotifTypes; t++ )
    {
      pMotif = M[t]->Motifs;
      while( pMotif != NULL )
	{
	  if( pMotif->pos != pCurMotif->pos )
	    {
	      if( pCurMotif->seq_num == pMotif->seq_num )
		{
		  if( dir == RIGHT )
		    {
		      if( pCurMotif->pos < pMotif->pos )
			{
			  if( !pCurMotif->RevComp )
			    {
			      if( !pMotif->RevComp )
				if( pCurMotif->pos + w - 1 >= pMotif->pos )
				  return TRUE;
			      else
				if( pCurMotif->pos + w - 1 >= pMotif->pos - (w - oldLen) )
				  return TRUE;
			    }
			  else
			    {
			      if( pMotif->RevComp )
				if( pCurMotif->pos - (w - oldLen) + w - 1 >= pMotif->pos - (w - oldLen) )
				  return TRUE;
			    }
			}
		      else
			{
			  if( !pCurMotif->RevComp )
			    {
			      if( !pMotif->RevComp )
				if( pMotif->pos + w - 1 >= pCurMotif->pos )
				  return TRUE;
			    }
			  else
			    {
			      if( !pMotif->RevComp )
				if( pMotif->pos + w - 1 >= pCurMotif->pos - (w - oldLen) )
				  return TRUE;
			      else
				if( pMotif->pos - (w - oldLen) + w - 1 >= pCurMotif->pos - (w - oldLen) )
				  return TRUE;				
			    }			  
			}
		    }
		  else
		    {
		      if( pCurMotif->pos < pMotif->pos )
			{
			  if( !pCurMotif->RevComp )
			    {
			      if( !pMotif->RevComp )
				if( pCurMotif->pos + oldLen - 1 >= pMotif->pos - (w - oldLen) )
				  return TRUE;
			    }
			  else
			    {
			      if( ! pMotif->RevComp )
				if( pCurMotif->pos + w - 1 >= pMotif->pos - (w - oldLen) )
				  return TRUE;
			      else
				if( pCurMotif->pos + w - 1 >= pMotif->pos )
				  return TRUE;
			    }
			}
		      else
			{
			  if( !pCurMotif->RevComp )
			    {
			      if( !pMotif->RevComp )
				if( pMotif->pos + w - 1 >= pCurMotif->pos - (w - oldLen) )
				  return TRUE;
			      else
				if( pMotif->pos + (w - oldLen) + w - 1 >=  pCurMotif->pos - (w - oldLen) )
				  return TRUE;
			    }
			  else
			    {
			      if( pMotif->RevComp )
				if( pMotif->pos + w - 1 >= pCurMotif->pos )
				  return TRUE;
			    }			  
			}		      
		    }
		}
	    }
	  pMotif = pMotif->next;
	}
    }

  return FALSE;
}


short CheckPossibleOverlap( Model B, int curPos, int w, int dir, Mlist M,  
			    MlistEl *pCurMotif, int oldLen )
{
  IPtype   IP;
  int      t;
  MlistEl  *pMotif;

  IP = B->IP;
  for( t = 0; t < IP->nNumMotifTypes; t++ )
    {
      pMotif = M[t]->Motifs;
      while( pMotif != NULL )
	{
	  if( pMotif->pos != pCurMotif->pos )
	    {
	      if( pCurMotif->seq_num == pMotif->seq_num )
		{
		  if( dir == RIGHT )
		    {
		      CheckPossibleOverlapRight( B, curPos, w, dir, M,  
						 pCurMotif, pMotif, oldLen, t );
		      /*			if( pCurMotif->pos < pMotif->pos )
			{
			  if( !pCurMotif->RevComp )
			    {
			      if( !pMotif->RevComp )
				{
				  if( pCurMotif->pos + w - 1 >= pMotif->pos )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][FORWARD]--;
				      return TRUE;
				    }
				}
			      else
				{
				  if( pCurMotif->pos + w - 1 >= pMotif->pos - (w - oldLen) )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][REVERSE]--;
				      return TRUE;
				    }
				}
			    }
			  else
			    {
			      if( pMotif->RevComp )
				{
				  if( pCurMotif->pos - (w - oldLen) + w - 1 >= pMotif->pos - (w - oldLen) )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][REVERSE]--;
				      return TRUE;
				    }
				}
			    }
			}
		      else
			{
			  if( !pCurMotif->RevComp )
			    {
			      if( !pMotif->RevComp )
				{
				  if( pMotif->pos + w - 1 >= pCurMotif->pos )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][FORWARD]--;
				      return TRUE;
				    }
				}
			    }
			  else
			    {
			      if( !pMotif->RevComp )
				{
				  if( pMotif->pos + w - 1 >= pCurMotif->pos - (w - oldLen) )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][FORWARD]--;
				      return TRUE;
				    }
				}
			      else
				{
				  if( pMotif->pos - (w - oldLen) + w - 1 >= pCurMotif->pos - (w - oldLen) )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][REVERSE]--;
				      return TRUE;
				    }
				}
			    }			  
			}
		      */  }
		  else
		    {
		      if( pCurMotif->pos < pMotif->pos )
			{
			  if( !pCurMotif->RevComp )
			    {
			      if( !pMotif->RevComp )
				{
				  if( pCurMotif->pos + oldLen - 1 >= pMotif->pos - (w - oldLen) )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][FORWARD]--;
				      return TRUE;
				    }
				}
			    }
			  else
			    {
			      if( ! pMotif->RevComp )
				{
				  if( pCurMotif->pos + w - 1 >= pMotif->pos - (w - oldLen) )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][FORWARD]--;
				      return TRUE;
				    }
				}
			      else
				{
				  if( pCurMotif->pos + w - 1 >= pMotif->pos )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][REVERSE]--;
				      return TRUE;
				    }
				}
			    }
			}
		      else
			{
			  if( !pCurMotif->RevComp )
			    {
			      if( !pMotif->RevComp )
				{
				  if( pMotif->pos + w - 1 >= pCurMotif->pos - (w - oldLen) )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][FORWARD]--;
				      return TRUE;
				    }
				}
			      else
				{
				  if( pMotif->pos + (w - oldLen) + w - 1 >=  pCurMotif->pos - (w - oldLen) )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][REVERSE]--;
				      return TRUE;
				    }
				}
			    }
			  else
			    {
			      if( pMotif->RevComp )
				{
				  if( pMotif->pos + w - 1 >= pCurMotif->pos )
				    {
				      delete_motif( B, pMotif->pos, M, t);
				      B->IP->nNumMotifs[t][REVERSE]--;
				      return TRUE;
				    }
				}
			    }			  
			}		      
		    }
		}
	    }
	  pMotif = pMotif->next;
	}
    }

  return FALSE;
}


void CheckPossibleOverlapRight( Model B, int curPos, int w, int dir, Mlist M,  
				MlistEl *pCurMotif, MlistEl *pMotif, int oldLen,
				int t )
{
  if( pCurMotif->pos < pMotif->pos )
    {
      if( !pCurMotif->RevComp )
	{
	  if( !pMotif->RevComp )
	    {
	      if( pCurMotif->pos + w - 1 >= pMotif->pos )
		{
		  delete_motif( B, pMotif->pos, M, t);
		  B->IP->nNumMotifs[t][FORWARD]--;
		}
	    }
	  else
	    {
	      if( pCurMotif->pos + w - 1 >= pMotif->pos - (w - oldLen) )
		{
		  delete_motif( B, pMotif->pos, M, t);
		  B->IP->nNumMotifs[t][REVERSE]--;
		}
	    }
	}
      else
	{
	  if( pMotif->RevComp )
	    {
	      if( pCurMotif->pos - (w - oldLen) + w - 1 >= pMotif->pos - (w - oldLen) )
		{
		  delete_motif( B, pMotif->pos, M, t);
		  B->IP->nNumMotifs[t][REVERSE]--;
		}
	    }
	}
    }
  else
    {
      if( !pCurMotif->RevComp )
	{
	  if( !pMotif->RevComp )
	    {
	      if( pMotif->pos + w - 1 >= pCurMotif->pos )
		{
		  delete_motif( B, pMotif->pos, M, t);
		  B->IP->nNumMotifs[t][FORWARD]--;
		}
	    }
	}
      else
	{
	  if( !pMotif->RevComp )
	    {
	      if( pMotif->pos + w - 1 >= pCurMotif->pos - (w - oldLen) )
		{
		  delete_motif( B, pMotif->pos, M, t);
		  B->IP->nNumMotifs[t][FORWARD]--;
		}
	    }
	  else
	    {
	      if( pMotif->pos - (w - oldLen) + w - 1 >= pCurMotif->pos - (w - oldLen) )
		{
		  delete_motif( B, pMotif->pos, M, t);
		  B->IP->nNumMotifs[t][REVERSE]--;
		}
	    }
	}			  
    }
}

short PossibleMotifWidth( int w, int t, Model B, PoSition **Pos, MlistEl *pMotif, int dir, int oldLen )
{
  IPtype  IP;

  IP = B->IP;

  if( dir == RIGHT )
    {
      if( pMotif->pos + w >= IP->nSeqLen || Pos[t][pMotif->pos].nSeq != Pos[t][pMotif->pos + w].nSeq|| 
	  PossibleOverlapsPrevMotif( B, pMotif->pos, t,  Pos ) )
	return FALSE;
    }
  else
    {
      if( pMotif->pos - (w - oldLen) < 0 || Pos[t][pMotif->pos].nSeq != Pos[t][pMotif->pos - (w - oldLen)].nSeq || 
	  pMotif->pos - (w - oldLen) >= IP->nSeqLen || 
	  PossibleOverlapsPrevMotif( B, pMotif->pos - (w - oldLen), t,  Pos ) )
	return FALSE;
    }

  return TRUE;
}


void ResetLengths( int w, int t, Model B, PoSition **Pos, Mlist M, int dir, int oldLen )
{
  IPtype   IP;
  MlistEl  *pMotif;
  MlistEl  *pOldMotif;
  MlistEl  *next;
  int      pos;
  int      t1;

  IP = B->IP;

  if( IP->nNumMotifs[t][FORWARD] == 18 &&
      IP->nNumMotifs[t][REVERSE] == 26 )
    IP = IP;                                    /* Debug */

  pMotif = M[t]->Motifs;
  while( pMotif != NULL )
    {
      not_in_motif( Pos, pMotif->pos, IP->nMotifLen, t );
      pMotif = pMotif->next;
    }

  if( ! PossibleWidth( w, t, B, Pos, M, dir, oldLen ) )
    p_error( "Invalid Length");

  IP->nMotifLen[t] = w;
  M[t]->nMotifLen = w;
  IP->nNumMotifs[t][FORWARD] = 0;
  IP->nNumMotifs[t][REVERSE]= 0;

  set_indicator_vector(Pos, B->Seq, IP);

  pMotif = M[t]->Motifs;
  pOldMotif = M[t]->Motifs;
  M[t]->Motifs = NULL;
  M[t]->nNumMotifs = 0;
  while( pMotif != NULL )
    {
      if( (dir == RIGHT && !pMotif->RevComp) ||
	  (dir == LEFT && pMotif->RevComp))
	pos = pMotif->pos;
      else
	pos = pMotif->pos - (w - oldLen);
      adjust_counts( B, ADD, pos, t, pMotif->RevComp );
      set_in_motif( Pos, pos, IP->nMotifLen, t, pMotif->RevComp );
      add_motif( B->Seq, pos, M, t,  pMotif->RevComp );
      if( pMotif->RevComp )
	IP->nNumMotifs[t][REVERSE]++;
      else
	IP->nNumMotifs[t][FORWARD]++;
      pMotif = pMotif->next;
    } 
  
  pMotif = pOldMotif;
  while( pMotif != NULL )
    {
      next = pMotif->next;
      free( pMotif );
      pMotif = next;
    }

  fprintf( stdout, "Motif %d width set to %d dir = %d motifs = %d\n", 
	   t, w, dir, NUMMOTIFS( IP->nNumMotifs[t] ) );
}


/*
void CopyMotifs( int t, Model B, PoSition **Pos, Mlist M, Mlist M2 )
{
  IPtype   IP;
  MlistEl  *pMotif;

  M2[t]->Motifs = NULL;
  M2[t]->nNumMotifs = 0;
  
  pMotif = M[t]->Motifs;
  while( pMotif != NULL )
    {
      add_motif( B->Seq, pMotif->pos, M2, t,  pMotif->RevComp );      
      pMotif = pMotif->next;
    }
}
*/

void CopyMotifs( int t, Model B, Mlist M, Mlist M2 )
{
  M2[t]->Motifs = NULL;
  M2[t]->nNumMotifs = 0;

  CopyTheMotif( M[t]->Motifs, t, B, M, M2 );
}


void CopyTheMotif( MlistEl *pMotif, int t, Model B, Mlist M, Mlist M2 )
{
  if( pMotif == NULL )
    return;

  CopyTheMotif( pMotif->next, t, B, M, M2 );
  add_motif( B->Seq, pMotif->pos, M2, t,  pMotif->RevComp );      
}


void ReleaseMotifs( int t, Mlist M2 )
{
  MlistEl  *pMotif;
  MlistEl  *next;

  pMotif = M2[t]->Motifs;
  while( pMotif != NULL )
    {
      next = pMotif->next;
      free( pMotif );
      pMotif = next;
    }

  M2[t] = NULL;
}


void ResetGoodPosition( int t, Model B, PoSition **Pos, Mlist M )
{
  IPtype   IP;
  MlistEl  *pMotif;
  MlistEl  *pOldMotif;
  MlistEl  *next;
  int      pos;
  int      goodPos[18] = {17, 17, 76, 63, 50, 7, 42, 39, 9, 14, 29, 41, 48, 71, 17, 53, 5, 78};
  int      i;

  IP = B->IP;
  pOldMotif = M[t]->Motifs;
  M[t]->Motifs = NULL;
  M[t]->nNumMotifs = 0;
  for( i = 0; i < 18; i++ )
    {
      set_in_motif( Pos, goodPos[i], IP->nMotifLen, t, FALSE );
      add_motif( B->Seq, goodPos[i], M, t,  FALSE );      
    }

  pMotif = pOldMotif;
  while( pMotif != NULL )
    {
      next = pMotif->next;
      free( pMotif );
      pMotif = next;
    }
}


void DumpCounts( Model B, int t )
{
  IPtype   IP;
  int      i;
  int      j;
  int      tot;
  int      tot2;
  int      sum1 = 0;
  int      sum2 = 0;

  fprintf( stdout, "\n" );
  IP = B->IP;
  for( i = 0; i < IP->nAlphaLen; i++ )
    {
      for( tot = 0, tot2 = 0, j = 0; j <= IP->nMotifLen[t]; j++ )
	{
	  fprintf( stdout, "%3d ", (int) B->C->fCounts[t][j][i] );
	  if( j > 0 )
	    tot += (int) B->C->fCounts[t][j][i];
	  else 
	    tot2 += (int) B->C->fCounts[t][j][i];
	}
      fprintf( stdout, "%4d\n", tot );
      sum1 += tot;
      sum2 += tot2;
      if( tot2 == 0 )
	tot2 = tot2;
    }
  fprintf( stdout, "sum1 = %5d\n", sum1 );
  fprintf( stdout, "sum2 = %5d\n", sum2 );
  fprintf( stdout, "Motifs: %3d %3d\n", B->IP->nNumMotifs[t][0],  B->IP->nNumMotifs[t][1] );
}


void DumpMotifs( Model B, Mlist M )
{
  IPtype   IP;
  int      t;
  MlistEl  *pMotif;

  IP = B->IP;
  for( t = 0; t < IP->nNumMotifTypes; t++ )
    {
      pMotif = M[t]->Motifs;
      while( pMotif != NULL )
	{
	  fprintf( stdout, "%4d, %4d %4d %4d\n", pMotif->seq_num, pMotif->pos, pMotif->left, pMotif->right );
	  pMotif = pMotif->next;
	}
    }
}


void DumpPositions( int t, Model B, PoSition **Pos )
{
  IPtype   IP;
  PoSition *pos_t;
  int      i;
  int      oldSeq = -1;
  char     c;

  pos_t = Pos[t];
  IP = B->IP;
  fprintf( stdout, "\n" );
  
  for( i = 0; i < IP->nSeqLen; i ++ )
    {
      if( pos_t[i].nSeq != oldSeq )
	{
	  fprintf( stdout, "|\n%2d |", pos_t[i].nSeq );
	  oldSeq = pos_t[i].nSeq;
	}
      if( pos_t[i].nMotifStartPos )
	{
	  if( pos_t[i].RevComp )
	    c = '-';
	  else 
	    c = '*';
	}
      if( pos_t[i].nInMotif )
	  fprintf( stdout, "%c", c );
      else
	fprintf( stdout, " " );
    }
  fprintf( stdout, "|\n" );
}


int GetMaxMotifWidth( Model B )
{
  int      i;
  int      len;
  int      t;
  int      minLen = INT_MAX;
  IPtype   IP;

  IP = B->IP;

  for( i = 0; i < IP->nNumSequences; i++ )
    {
      if( i == 0 )
	len = (*B->Seq->nvEndLocs)[i] - 1;
      else
	len = (*B->Seq->nvEndLocs)[i] - (*B->Seq->nvEndLocs)[i - 1] - 1;
      if( len < minLen )
	minLen = len;
    }  

  for( t = 0; t < IP->nNumMotifTypes; t++ )
    if( IP->nMaxMotifLen[t] < minLen )
      minLen = IP->nMaxMotifLen[t];

  return minLen;
}


double factrl( int n )
/* Return n! as a double. Adapted from Numerical Recipes p214 */
{
  static int ntop = 4;
  static double a[33] = {1.0, 1.0, 2.0, 6.0, 24.0};
  int j;

  if( n < 0 )
    p_error( "Negative factorial in factrl." );

  if( n > 32 )
    return exp( ln_gamma( n + 1.0 ) );

  while( ntop < n )
    {
      j = ntop++;
      a[ntop] = a[j] * ntop;
    }

  return a[n];
}


double ln_factrl( int n )
{
  static double a[101];

  if( n < 0 )
    p_error( "Negative factorial in ln_factrl." );

  if( n <= 1 )
    return 0.0;

  if( n <= 32 )
    return (a[n] ? a[n] : (a[n] = log( factrl( n ) )));
  else if( n <= 100 )
    return (a[n] ? a[n] : (a[n] = ln_gamma( n + 1.0 )));
  else
    return ln_gamma( n + 1.0 );
}
