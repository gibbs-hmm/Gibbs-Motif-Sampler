/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/* code for finidng segments from two sequences with maximum similarity     */
/* adapted from "Mathematical Methods for DNA Sequences" by M. S. Waterman  */

/* sequence lengths */
int m,n;

/* alphabet for protein sequence */
char Alpha[]={'
/* total number of blocks */
int N_BLOCK=8;

/* sequences as arrays of characters */
char *x,  /* x[1]...x[m] */
     *y;  /* y[1]...y[n] */

/* score cells as arrays of short intergers */
short ***S; /* S[0][0][0]....S[k][m][n] */

#include <stdio.h>
#include "stdinc.h"

void main(int argc, char **argv)
{
  FILE *fp;      /* file pointer */
  char c;        /* the character read from the file */
  int  i,j,k;    /* general register */

  /* open file */
  if((fp=fopen(argv[1],"r"))==NULL)
  {
      /* can not open the file */
      printf("can not open file %s \n",argv[1]);
      return;
  }
  
  m=0;
  n=0;

  /* read the first sequence */
  while((c=fgetc(fp))!=EOF){ if(c=='>') break; }
  if(c==EOF)
  {
      printf("File not in fasta format!\n");
      exit(-1);
  }
  /* skip the comment */ 
  while((c=fgetc(fp))!=EOF){ if(c=='\n') break; }
  if(c==EOF)
  {
      printf("Empty sequence!\n");
      exit(-1);
  }  
  while((c=fgetc(fp))!='>') 
  {
	  if(isalpha(c))
	    m++;
	  else if(c==EOF) 
	    exit(-1);
  } 
  /* read second sequence */
  /* skip the comment */ 
  while((c=fgetc(fp))!=EOF){ if(c=='\n') break; }
  if(c==EOF)
  {
      printf("Empty sequence!\n");
      exit(-1);
  }  
  while((c=fgetc(fp))!='>') 
  {
	  if(isalpha(c))
	    n++;
	  else if(c==EOF)
	    break;
  } 

  /* allocate the space for sequences */
  x=(char *)malloc(sizeof(char)*(m+1));
  y=(char *)malloc(sizeof(char)*(n+1));

  /* go back to the start of file */
  rewind(fp);
   
  /* read in the sequences */
  i=0;

  /* read the first sequence */
  while((c=fgetc(fp))!=EOF){ if(c=='>') break; }
  if(c==EOF)
  {
      printf("File not in fasta format!\n");
      exit(-1);
  }
  /* skip the comment */ 
  while((c=fgetc(fp))!=EOF){ if(c=='\n') break; }
  if(c==EOF)
  {
      printf("Empty sequence!\n");
      exit(-1);
  }  
  while((c=fgetc(fp))!='>') 
  {
	  if(isalpha(c))
	    {
	      i++;
	      x[i]=c;
	    }
	  else if(c==EOF) exit(-1);
  } 

  /* read second sequence */
  i=0;
  /* skip the comment */ 
  while((c=fgetc(fp))!=EOF){ if(c=='\n') break; }
  if(c==EOF)
  {
      printf("Empty sequence!\n");
      exit(-1);
  }  
  while((c=fgetc(fp))!='>') 
  {
      if(isalpha(c))
      {
	  i++;
	  y[i]=c;
      }
      else if(c==EOF) break;
  } 
  fclose(fp);

  printf("> number of element %d\n",m);
  for(j=1;j<=m;j++)
    {
      printf("%c",x[j]);
      if(j%10==0) printf(" ");
      if(j%50==0) printf("\n");
    }
  printf("\n");
  printf(">number of element %d\n",n);
  for(j=1;j<=n;j++)
    {
      printf("%c",y[j]);
      if(j%10==0) printf(" ");
      if(j%50==0) printf("\n");
    }
  printf("\n");

  /* allocate space for S[k][i][j] */
  NEWPP(S,N_BLOCK+1,short);
  for(k=0;k<=N_BLOCK;k++)
    {
      NEWP(S[k],m+1,short);
    }
  for(k=0;k<=N_BLOCK;k++)
    {
      for(i=0;i<=m;++i)
	{
	  NEW(S[k][i],n+1,short);
	}
    }
  /* initialize the S */
}

int nAlpha(char c)

