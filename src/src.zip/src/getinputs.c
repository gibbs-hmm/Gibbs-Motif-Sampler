/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
#include "common.h"

void set_pseudoSiteWt(IPtype IP)
{
   IP->dPseudoSiteWt = 1.0;
   while((IP->dPseudoSiteWt < 0.0) || (IP->dPseudoSiteWt >=1.0)) {
      printf("Enter in the Pseudo Site Weight (between 0 and 1) : ");
      scanf("%lf", &IP->dPseudoSiteWt);
   }
}

void set_SeedVal(IPtype IP)
{
   printf("Enter in the seed value to explore : ");
   scanf("%ld", &IP->lSeedVal);
   IP->nSeeds = 1;
   IP->is_defined[cl_s] = TRUE;
}

void set_MaxIterations(IPtype IP)
{
   char *tmpstr=(char *)malloc(10 * sizeof(char));
   IP->nMaxIterations = 0;
   while(IP->nMaxIterations < 1) {
      printf("Enter in the maximum number of iterations \n");
      scanf("%s", tmpstr);
      IP->nMaxIterations = atoi(tmpstr);
   }
   free(tmpstr);
}

void set_pseudoWt(IPtype IP)
{
   IP->dPseudoCntWt = 1.0;
   while((IP->dPseudoCntWt < 0.0) || (IP->dPseudoCntWt >= 1.0)) {
      printf("Enter the pseduo count weight (0 <= wt < 1) : ");
      scanf("%lf", &IP->dPseudoCntWt);
   }
}

void set_plateauPer(IPtype IP)
{
   char *tmpstr=(char *)malloc(10 * sizeof(char));

   IP->nPlateauPeriods = 0;
   while(IP->nPlateauPeriods < 1) {
      printf("Enter the maximium periods allowable between local maximums : ");
      scanf("%s", tmpstr);
      IP->nPlateauPeriods = atoi(tmpstr);
   }
}

void set_filename(IPtype IP)
{
   char *tmpstr=(char *)malloc(80 * sizeof(char));

   IP->Datafiles->filename = (char *)malloc(256 * sizeof(char));
   printf("Enter the file name where the sequences are located : ");
   scanf("%s", IP->Datafiles->filename);
   IP->Datafiles->fpt = fopen(IP->Datafiles->filename, "r");
   if(IP->Datafiles->fpt == NULL) {
      sprintf(tmpstr, "cannot open file %s", IP->Datafiles->filename);
      perror(tmpstr);
   }
   free(tmpstr);
}

void set_priorFile(IPtype IP)
{
   char *tmpstr = (char *)malloc(80 * sizeof(char));

   IP->Datafiles->prior_filename = (char *)malloc(256 * sizeof(char));
   printf("Enter the file name where the prior information is located : ");
   scanf("%s", IP->Datafiles->prior_filename);
   IP->Datafiles->prior_fpt = fopen(IP->Datafiles->prior_filename, "r");
   if(IP->Datafiles->prior_fpt == NULL) {
      sprintf(tmpstr, "cannot open file %s", IP->Datafiles->prior_filename);
      perror(tmpstr);
   }
   free(tmpstr);
   IP->is_defined[cl_P] = TRUE;
}


void set_outputFile(IPtype IP)
{
   char *tmpstr = (char *)malloc(80 * sizeof(char));

   IP->Datafiles->output_filename = (char *)malloc(256 * sizeof(char));
   printf("Enter the file name where the output is to be directed : ");
   scanf("%s", IP->Datafiles->output_filename);
   IP->Datafiles->out_fpt = fopen(IP->Datafiles->output_filename, "w");
   if(IP->Datafiles->out_fpt == NULL) {
      sprintf(tmpstr, "cannot open file %s", IP->Datafiles->output_filename);
      perror(tmpstr);
   }
   free(tmpstr);
   IP->is_defined[cl_o] = TRUE;
}


void set_sequence_type(IPtype IP)
{
   char *tmpstr=(char *)malloc(10 * sizeof(char));

   IP->nAlphaLen = 0;
   while(IP->nAlphaLen == 0) {
      printf("Enter 0 for nucleic acid sequencing\n");
      printf("or    1 for amino acid sequencing\n");
      printf("--> ");
      scanf("%s", tmpstr);
      if(atoi(tmpstr) == 0)
         IP->nAlphaLen = 4;
      else if(atoi(tmpstr) == 1)
         IP->nAlphaLen = 20;
   }
   free(tmpstr);
}

void set_numMotifs(IPtype IP)
{
   char *tmpstr = (char *)malloc(10 * sizeof(char));
   IP->nNumMotifs[0][FORWARD] = 0;
   while(IP->nNumMotifs[0][FORWARD] < 1) {
      printf("Enter the number of predicted binding sites : ");
      scanf("%s", tmpstr);
      IP->nNumMotifs[0][FORWARD] = atoi(tmpstr);
   }
   free(tmpstr);
}

void set_motifLen(IPtype IP)
{
   char *tmpstr = (char *)malloc(10 * sizeof(char));
   IP->nMotifLen[0] = 0;
   while(IP->nMotifLen[0] < 1) {
      printf("Enter the desired motif length : ");
      scanf("%s", tmpstr);
      IP->nMotifLen[0] = atoi(tmpstr);
   }
   free(tmpstr);
}
void set_numSeeds(IPtype IP)
{
   char *tmpstr = (char *)malloc(10 * sizeof(char));
   IP->nSeeds = 0;
   while(IP->nSeeds < 1) {
      printf("Enter in the number of seeds to try : ");
      scanf("%s", tmpstr);
      IP->nSeeds = atoi(tmpstr);
   }
}

void confirm_data(IPtype IP)
   /** This function probabily will be taken out **/
{
   char choice;
   int finished = FALSE;
  
   while(!finished) {
      choice = getc(stdin);
      printf("                      Input Parameters\n");
      printf("____________________________________________________________\n");
      printf("(1)  input file                 : %s\n", IP->Datafiles->filename);
      printf("(2)  # of predicted motif sites : %d\n", IP->nNumMotifs[0][FORWARD
]);
      printf("(3)  Motif width                : %d\n", IP->nMotifLen[0]);
      printf("(4)  Type of sequence studied   : ");
      if(IP->nAlphaLen == 4)
        printf("DNA\n");
      else
         printf("Protein\n");
      printf("(5)  Pseudocount weights        : %.2f\n", IP->dPseudoCntWt);
      printf("(6)  Maximum iterations         : %d\n", IP->nMaxIterations);
      printf("(7)  Seedval                    : ");
      if(IP->is_defined[cl_s])
         printf("%ld\n", IP->lSeedVal);
      else
         printf("n/a\n");
      printf("(8)  Plateau Periods            : %d\n", IP->nPlateauPeriods);
      printf("(9)  Seeds to Try               : %d\n", IP->nSeeds);
      printf("(a)  Pseudosite weights         : %.2f\n", IP->dPseudoSiteWt);
      printf("(b)  Prior Data                 : ");
      if(IP->is_defined[cl_P])
         printf("%s\n", IP->Datafiles->prior_filename);
      else
         printf("n/a\n");
      printf("(c)  Output File                : ");
      if(IP->is_defined[cl_o])
         printf("%s\n", IP->Datafiles->output_filename);
      else
         printf("n/a\n");

      printf("\n(0)  Continue with these values\n");
      printf("\nSELECTION --> ");
      choice = getc(stdin);
      switch(choice) {
         case '0': finished = TRUE; break;
         case '1': set_filename(IP); break;
         case '2': set_numMotifs(IP); break;
         case '3': set_motifLen(IP); break;
         case '4': set_sequence_type(IP); break;
         case '5': set_pseudoWt(IP); break;
         case '6': set_MaxIterations(IP); break;
         case '7': set_SeedVal(IP); break;
         case '8': set_plateauPer(IP); break;
         case '9': set_numSeeds(IP); break;
         case 'a': set_pseudoSiteWt(IP); break;
         case 'b': set_priorFile(IP); break;
         case 'c': set_outputFile(IP); break;
         default: break;
      }     
   }
}
