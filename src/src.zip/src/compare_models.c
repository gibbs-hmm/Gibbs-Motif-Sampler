/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/**************************************************************************/
/* FILE : compare_models.c                                                */
/*                                                                        */
/* Author :       Eric C. Rouchka                                         */
/* Last Update :  July  22, 1996                                          */
/* Description :  This file is contains the main function that drives the */
/*                Bernoulli sampling alorithm for comparing models        */
/**************************************************************************/

#include "calcstats.h"
#include "common.h"                             
#include "counts.h"
#include "mem_mgmt.h"
#include "parameters.h"             
#include "printdata.h"
#include "probability.h"
#include "process.h"
#include "sampling.h"
#include <curses.h>

void getargs(int *argcnt, char ***argvec);

void getargs(int *argcnt, char ***argvec)
{
   int pos=0;
   char ch;
   ch = getc(stdin);
   (*argcnt) = 1;
      while(ch != '\n') {
         if(ch != ' ') {
            (*argvec)[(*argcnt)][pos] = ch;
            if(pos >= 50) 
               p_error("Argument too long");
            ch = getc(stdin);
            pos++;
         }
         else {
            (*argcnt)++; 
            pos = 0;
            while(ch == ' ')
               ch = getc(stdin);
         }
      }
      (*argcnt)++;
}



int main(int argc, char **argv)
{
   Model  M;
   int    Finished=FALSE, t, i=0;
   char   *tmp;
   double cmp_logl, dof;
   int    arglen, argcnt, pos;
   char  **argvec, ch; 
   MCstruct *List, *First;
   MCstruct *curr;
 
   List = NULL;
   First = NULL;

   Finished = FALSE;
   while (!Finished) {
      NEWP(argvec, 50, char);
      for(i = 0; i < 50; i++)
         NEW(argvec[i], 100, char);
      print_EnterArgs();
      fflush(stdin);
      strcpy(argvec[0], argv[0]);
  
      getargs(&argcnt, &argvec);
      for(i = 0; i < argcnt; i++)
         printf("%s\n", argvec[i]);

      NEW(curr, 1, MCstruct);
      if(List == NULL)  
         List = First = curr;
      else {
         List->next = curr;
         List = curr;
      }
      curr->next = NULL;
 
 
      printf("Enter a description of the model : "); 
      NEW(tmp, 1000, char);
      gets(tmp);
      NEW(curr->desc, strlen(tmp), char);
      for(i = 0; i < strlen(tmp); i++)
         curr->desc[i] = tmp[i];
      curr->desc[i] = '\0';
      free(tmp);
      printf("Enter a description of the model compared to : ");
      NEW(tmp, 1000, char);
      gets(tmp);
      NEW(curr->cmp_desc, strlen(tmp), char);
      for(i = 0; i < strlen(tmp); i++)
         curr->cmp_desc[i] = tmp[i];
      curr->cmp_desc[i] = '\0';
      free(tmp);
      printf("Enter in the comparison model's log l value : ");
      scanf("%lf", &(curr->cmp_logl));
      printf("Enter in the # of degrees of freedom to find P value: ");
      scanf("%lf", &(curr->dof));
      
      M = alloc_Model();
      stripargs(argcnt, argvec, M->IP, FALSE, 0);  /* Get arguments from command line */

      get_inputs(M);
      get_strings(M->IP, M->Seq);                     /* Read the sequences */
      alloc_Counts(M);
      set_counts(M);                              /* Set the initial counts */
      set_posterior_prob(M->IP, M->First);    /* Set initial posterior prob */
      *M->Seq->ProcessedSTR = Xnu_Sequence(M);   /* preprocess the sequence */
      set_pseudo_counts(M, M->IP, M->First);     /* Set initial pseudo counts  */
      find_best_sites(M);                     /* find maximal alignment     */
      curr->logl = M->IP->Logl; 
      curr->lrt = fabs(2.0 * (curr->cmp_logl - curr->logl));
      curr->pval = Pval(curr->dof, curr->lrt);
      print_curr(curr);
      for(t = 0; t < M->IP->nNumMotifTypes; t++)
          fprintf(stdout, "DOF[%d] = %d (Compared to Monoresidue model) \n", t, 
                  M->IP->DOF[t]);
      fprintf(stdout, "Another Model to compare (y/n)? ");
      fflush(stdin);

      scanf("%c", &ch);
      printf("ch = %c\n", ch);
      Finished = (ch == 'n');
      if(!Finished)
      { 

      }
      FreeData(M);
/***
      Finished = TRUE;
***/
      
      for(i = 0; i < 50; i++)
         free(argvec[i]);
      free(argvec);
         /* get new arguments */
   }
   print_all_desc(First);
   return(0);
}
