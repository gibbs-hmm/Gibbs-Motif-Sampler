/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/**************************************************************************/
/*                                                                        */
/* $Header: /home/junzhu1/proj/RCS/GUI_Bernoulli.c,v 1.2                  */
/*1996/08/29 21:09:03 junzhu Exp junzhu $                                 */
/*                                                                        */
/* $Author: Bill $                                                      */
/*	    Bill Thompson 1/27/97                                         */
/* $Date: 2007/05/23 18:19:55 $                                           */
/* Description: Create GUI for Bernoulli                                  */
/**************************************************************************/

#include <stdio.h>
#include "GUI_common.h"
#include <Xm/Text.h>
#include <Xm/ToggleBG.h>
#include <Xm/Scale.h>
#include <Xm/ToggleB.h>
#include "common.h"                             
#include "parameters.h"             
#include "printdata.h"
#include "counts.h"
#include "probability.h"
#include "sampling.h"
#include "process.h"
#include "mem_mgmt.h"
#include "width.h"      /* BT 5/12/97 */
#include "prior.h"

/* subroutine used here */
void GUI_Bernoulli_pop(Widget, caddr_t, caddr_t);
void GUI_Bernoulli_accept(Widget, caddr_t, caddr_t);
void GUI_Bernoulli_stop(Widget, caddr_t, caddr_t);
void GUI_Bernoulli_toggle(Widget parent, void *data, void *call_data);  /* BT 12/09/99 */
void GUI_Bernoulli_width_radio_toggle(Widget parent, void *data, void *call_data);  /* BT 12/9/99 */
void GUI_Bernoulli_propagation_toggle(Widget parent, caddr_t data, caddr_t call_data);


/* file scope variables */
    Widget        iw_Bernoulli = (Widget)0;
    Widget        iwb_rowcol;        /* rowcol to contain buttons */
    Widget        iwb_label;         /* label for function */
    Widget        butb_protein;      /* button for protein */
    Widget        butb_DNA;          /* button for DNA     */
    Widget        butb_stop;         /* button for stop    */
    Widget        butb_accept;       /* button for accept  */
    Widget        iwb_pseudo_site_wt;/* scale bar for pseudo site weight */
    Widget        iwb_pseudo_cnt_wt; /* scale bar for pseudo count weight*/
    Widget        iwb_iteration_num;
    Widget        iwb_num_Seed;
    Widget        iwb_init_seed;
    Widget        iwb_init_seed_val;
    Widget        iwb_plateau_per;
    Widget        iwb_priority_file;
    Widget        iwb_priority_file_name;
    Widget        iwb_out_file;
    Widget        iwb_out_file_name;
    Widget        iwb_cutoff_value;
    Widget        iwb_collapse;
    Widget        iwb_concentrate;
    Widget        iwb_revs_cmpl;
    Widget        iwb_fragment;
    Widget        iwb_Xnu;
    Widget        iwb_maximization;
    Widget        iwb_EM;
    Widget        iwb_display_site;
    Widget        iwb_inputfile;
    Widget        iwb_motif_length;
    Widget        iwb_palindromic;
    Widget        iwb_motif_number;
    Widget	  iwb_palindromic_list;			/* BT 2/10/97 */
    Widget	  iwb_collapsed_list;			/* BT 2/10/97 */
    Widget	  iwb_concentrate_list;			/* BT 2/10/97 */
    Widget	  iwb_subopt_output;			/* BT 3/19/97 */
    Widget	  iwb_overlap;				/* BT 4/23/97 */
    Widget        iwb_width;                            /* BT 6/9/97 */
    Widget        iwb_shift;                            /* BT 6/9/97 */
    Widget        iwb_wilcoxon;                         /* BT 7/9/97 */
    Widget        iwb_minmaxwidth;                      /* BT 7/18/97 */
    Widget        iwb_lensample;                        /* BT 9/10/97 */   
    Widget        iwb_scan_file;                        /* BT 9/17/97 */
    Widget        iwb_scan_file_name;                   /* BT 9/17/97 */
    Widget        iwb_prout_file;                       /* BT 9/29/97 */
    Widget        iwb_prout_file_name;                  /* BT 9/29/97 */
    Widget        iwb_propagation;                      /* BT 12/17/97 */
    Widget        iwb_wilcoxon_filename;                /* BT 1/28/98 */
    Widget        iwb_ignorespacing;                    /* BT 6/10/98 */
    Widget        iwb_adjust_per;                       /* BT 9/11/98 */


void GUI_Bernoulli(Widget iw_temp, caddr_t data, caddr_t call_data)
{ 
    Arg           args[10];         /* arg list */
    register      int  n;           /* arg count */

    if(iw_Bernoulli==(Widget)0)	
      { 

	/* create a menu widget first */        
	iw_Bernoulli = wid_dialog(canvas,0,"Bernoulli sampler",
                                 30,30);

	iwb_rowcol   = wid_rowcol(iw_Bernoulli ,'v',-1,-1);
	iwb_label=wid_labelg(iwb_rowcol,0,"Bernoulli Sampler",0,0);
	butb_protein=wid_pushg(iwb_rowcol,0,"For protein",
                         GUI_Bernoulli_pop,"protein",0,0);
	butb_DNA=wid_pushg(iwb_rowcol,0,"For DNA",
                         GUI_Bernoulli_pop,"DNA",0,0);
	butb_stop=wid_pushg(iwb_rowcol,0,"Stop",
                         GUI_Bernoulli_stop,NULL,0,0);

      }
    else
	iw_Bernoulli = wid_dialog(canvas,iw_Bernoulli,"Bernoulli sampler",
                                 30,30);      
    XtManageChild(iw_Bernoulli);

}


/************ selection button callback *********************************/

void GUI_Bernoulli_pop(Widget iw_temp, caddr_t data, caddr_t call_data)
{
     Widget rowcol_tmp;
     char cval[FILENAME_MAX];     /* temp string to hold parameter value */ /* BT 7/9/97 */
     XmString temp_string;    /* BT 9/29/97 */

     XtUnmanageChild(iw_Bernoulli);
     if(strcmp((char*)data,"protein")==0)
	{/* option for protein */

	  /* reset the top label */
	  /*	  iwb_label=wid_labelg(iwb_rowcol,iwb_label,
          "                   Bernoulli Sampler for Protein",0,0);    */
	 temp_string = XmStringCreateLocalized("Bernoulli Sampler for Proteins");
	 XtVaSetValues( iw_Bernoulli, XmNdialogTitle, temp_string, NULL );
	 XmStringFree( temp_string );
	}
     else
       {  /* option for DNA */
	  /* reset the top label */
	 /*	  iwb_label=wid_labelg(iwb_rowcol,iwb_label,
	  "                   Bernoulli Sampler for DNA",0,0); */    /* BT 9/29/97 */
	 temp_string = XmStringCreateLocalized("Bernoulli Sampler for DNA");
	 XtVaSetValues( iw_Bernoulli, XmNdialogTitle, temp_string, NULL );
	 XmStringFree( temp_string );
       }

     /* unmanage the buttons */
     XtUnmanageChild(butb_protein);
     XtUnmanageChild(butb_DNA);
     XtUnmanageChild(butb_stop);
     XtUnmanageChild(iwb_label);       /* BT 9/29/97 */

     /* widget for input file */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1); 
     sprintf(cval,"%s"," ");
     iwb_inputfile=wid_textboxb(rowcol_tmp,0,"Input data file:",cval, 80);     /* BT 4/25/97 */

     /* widget for motif length and motif number */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1); 
     sprintf(cval,"%s"," ");
     /* use recursive sampling routine */
     iwb_propagation = wid_toggleg(rowcol_tmp, 0, "Recursive Sampler", False,
				   GUI_Bernoulli_propagation_toggle,
				   NULL,-1,-1);
     iwb_motif_length=wid_textboxb(rowcol_tmp,0,"Motif length:",cval,15);    
     iwb_motif_number=wid_textboxb(rowcol_tmp,0,"Number of Motifs:",cval,15);

     /* for pseudosite weight and pseudocount weight */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);
     iwb_pseudo_site_wt=wid_scale(rowcol_tmp,0,"Pseudo site weight (%)",0,100,
			     PSEUDO_SITE_WT*100,180,50);
     iwb_pseudo_cnt_wt=wid_scale(rowcol_tmp,0,"Pseudo count weight (%)",0,100,
				 PSEUDO_CNT_WT*100,180,50);     

     /* for iteration number and number of seed */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);
     sprintf(cval,"%d",MAX_ITERATIONS);
     iwb_iteration_num=wid_textboxb(rowcol_tmp,0,"Maximum iteration number",
				    cval,10);
     sprintf(cval,"%d",NUM_SEEDS);
     iwb_num_Seed=wid_textboxb(rowcol_tmp,0,"Number of seeds",cval,10);

     /* for initial seed and plateau number */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);
     iwb_init_seed=wid_toggleg(rowcol_tmp,0,"Previous seed",False,
			     GUI_Bernoulli_toggle,
			     NULL,-1,-1);

     iwb_init_seed_val=wid_textboxb(rowcol_tmp,0,
				  "Prev. seed:"," ",10);     
     XtUnmanageChild(XtParent(iwb_init_seed_val));
     XtRemoveAllCallbacks(iwb_init_seed, XmNvalueChangedCallback);
     XtAddCallback(iwb_init_seed,XmNvalueChangedCallback,
		   GUI_Bernoulli_toggle,iwb_init_seed_val);

     sprintf(cval,"%d",PLATEAU_PERIODS);
     iwb_plateau_per=wid_textboxb(rowcol_tmp,0,
				  "      Plateau Period",cval,10);     

     sprintf(cval,"%d", 5);
     iwb_adjust_per=wid_textboxb(rowcol_tmp,0,
				  "      Adjust Period",cval,10);     

     /* for output file */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);
     iwb_out_file=wid_toggleg(rowcol_tmp,0,"Output to file?",False,
				   GUI_Bernoulli_toggle,NULL,-1,-1);
     sprintf(cval,"%s"," ");
     iwb_out_file_name=wid_textboxb(rowcol_tmp,0,
				  "Output file name:",cval, 55);  /* BT 4/25/97 */
     XtUnmanageChild(XtParent(iwb_out_file_name));
     XtRemoveAllCallbacks(iwb_out_file, XmNvalueChangedCallback);
     XtAddCallback(iwb_out_file,XmNvalueChangedCallback,
		   GUI_Bernoulli_toggle,iwb_out_file_name);

     /* for priority file  */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);
     iwb_priority_file=wid_toggleg(rowcol_tmp,0,"Initial priors?",False,
				   GUI_Bernoulli_toggle,NULL,-1,-1);
     sprintf(cval,"%s"," ");
     iwb_priority_file_name=wid_textboxb(rowcol_tmp,0,
				  "Priority file name:",cval, 55);  /* BT 4/25/97 */
     XtUnmanageChild(XtParent(iwb_priority_file_name));
     XtRemoveAllCallbacks(iwb_priority_file, XmNvalueChangedCallback);
     XtAddCallback(iwb_priority_file,XmNvalueChangedCallback,
		   GUI_Bernoulli_toggle,iwb_priority_file_name);

     /* for prior output file  */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);                        /* BT 9/29/97 */
     iwb_prout_file=wid_toggleg(rowcol_tmp,0,"Prior Output File?",False,
				   GUI_Bernoulli_toggle,NULL,-1,-1);
     sprintf(cval,"%s"," ");
     iwb_prout_file_name=wid_textboxb(rowcol_tmp,0,
				  "Prior Output file name:",cval, 55);  /* BT 4/25/97 */
     XtUnmanageChild(XtParent(iwb_prout_file_name));
     XtRemoveAllCallbacks(iwb_prout_file, XmNvalueChangedCallback);
     XtAddCallback(iwb_prout_file,XmNvalueChangedCallback,
		   GUI_Bernoulli_toggle,iwb_prout_file_name);

     /* for scan file  */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);                        /* BT 9/17/97 */
     iwb_scan_file=wid_toggleg(rowcol_tmp,0,"Create Scan File?",False,
				   GUI_Bernoulli_toggle,NULL,-1,-1);
     sprintf(cval,"%s"," ");
     iwb_scan_file_name=wid_textboxb(rowcol_tmp,0,
				  "Scan file name:",cval, 55);  /* BT 4/25/97 */
     XtUnmanageChild(XtParent(iwb_scan_file_name));
     XtRemoveAllCallbacks(iwb_scan_file, XmNvalueChangedCallback);
     XtAddCallback(iwb_scan_file,XmNvalueChangedCallback,
		   GUI_Bernoulli_toggle,iwb_scan_file_name);

     /* for cutoff value */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);
     iwb_cutoff_value=wid_scale(rowcol_tmp,0,"Cutoff value (x100)",0,100,
				   0.5*100,180,50);

     if(strcmp((char*)data,"DNA")==0)
     {     /* option for DNA */

           /* for overlap at ends */		/* BT 4/23/97 */
           iwb_overlap=wid_scale(rowcol_tmp,0,"End Overlap (x100)",0, 50,
				   0.0*100,180,50);

           /* Alternative model of palindromic position for DNA */
           rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);  
           iwb_palindromic=wid_toggleg(rowcol_tmp,0,                         /* BT 10/1/97 */
			      "Alt palindromic position?",
			      False,GUI_Bernoulli_toggle,NULL,-1,-1);

           sprintf(cval,"%s"," ");			/* BT 2/10/97 */
	   /*           iwb_palindromic_list=wid_textboxb(rowcol_tmp,0,
				  "Palindrome list:",cval,20);     */
           iwb_palindromic_list=wid_textboxb(rowcol_tmp,0,
				  " ",cval,20);  
           XtUnmanageChild(XtParent(iwb_palindromic_list));
           XtRemoveAllCallbacks(iwb_palindromic, XmNvalueChangedCallback);
           XtAddCallback(iwb_palindromic,XmNvalueChangedCallback,
  		         GUI_Bernoulli_toggle,iwb_palindromic_list);


            /* Alternative model of a collapsed alphabet */
	   /*           rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);    */     /* BT 10/1/97 */
           iwb_collapse=wid_toggleg(rowcol_tmp,0,
			      "Alt collapsed alphabet?",
			      False,GUI_Bernoulli_toggle,NULL,-1,-1);

           sprintf(cval,"%s"," ");			/* BT 2/10/97 */
	   /*           iwb_collapsed_list=wid_textboxb(rowcol_tmp,0,
				  "Collapsed alphabet list:",cval,20);   */
           iwb_collapsed_list=wid_textboxb(rowcol_tmp,0,
				  " ",cval,20);  
           XtUnmanageChild(XtParent(iwb_collapsed_list));
           XtRemoveAllCallbacks(iwb_collapse, XmNvalueChangedCallback);
           XtAddCallback(iwb_collapse,XmNvalueChangedCallback,
  		         GUI_Bernoulli_toggle,iwb_collapsed_list);

           /* Alternative model of concentrated position for DNA */
           rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);  
           iwb_concentrate=wid_toggleg(rowcol_tmp,0,
			      "Altconcentrated position?",    /* 10/1/97 */
			      False,GUI_Bernoulli_toggle,NULL,-1,-1);
           sprintf(cval,"%s"," ");			/* BT 2/10/97 */
	   /*	   iwb_concentrate_list=wid_textboxb(rowcol_tmp,0,
				  "Concentrated positions:",cval,20);   */
	   iwb_concentrate_list=wid_textboxb(rowcol_tmp,0,
				  " ",cval,20); 
           XtUnmanageChild(XtParent(iwb_concentrate_list));
           XtRemoveAllCallbacks(iwb_concentrate, XmNvalueChangedCallback);
           XtAddCallback(iwb_concentrate,XmNvalueChangedCallback,
  		         GUI_Bernoulli_toggle,iwb_concentrate_list);
 
           /* reverse complementation */
	   rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);  
           iwb_revs_cmpl=wid_toggleg(rowcol_tmp,0,
			      "Reverse complement?",
			      True,GUI_Bernoulli_toggle,NULL,-1,-1);    
     }

     /* sample successive positions after a site is chosen */
     iwb_lensample = wid_toggleg(rowcol_tmp,0,
				 "Sample width after site is chosen?",
				 FALSE,GUI_Bernoulli_toggle,NULL,-1,-1); 

     /* Spacing Model   BT 06/10/98  */
     iwb_ignorespacing = wid_toggleg(rowcol_tmp,0,
				     "Ignore Spacing Model?",
				     FALSE,GUI_Bernoulli_toggle,NULL,-1,-1); 
     XtSetSensitive(iwb_ignorespacing, FALSE);

     /* Wilcoxon signed-rank test */    /* BT 1/28/98 */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);
     iwb_wilcoxon = wid_toggleg(rowcol_tmp,0,
				"Wilcoxon signed-rank test?",
				FALSE,GUI_Bernoulli_toggle,NULL,-1,-1); 
     sprintf(cval,"%s"," ");			
     iwb_wilcoxon_filename = wid_textboxb(rowcol_tmp,0,
					  "Control File Name: ",cval,40); 
     XtUnmanageChild(XtParent(iwb_wilcoxon_filename));
     XtRemoveAllCallbacks(iwb_wilcoxon, XmNvalueChangedCallback);
     XtAddCallback(iwb_wilcoxon,XmNvalueChangedCallback,
		   GUI_Bernoulli_toggle,iwb_wilcoxon_filename);

     /* flag for fregmentation, purge low complexity region(XNU),  */
     /* maximization,expectation maximization,display site used    */
     /* in near optimal sampling                                   */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);
     iwb_fragment=wid_toggleg(rowcol_tmp,0,
			      "Fragmentation",FALSE,
			      GUI_Bernoulli_width_radio_toggle,NULL,-1,-1);
     XtRemoveAllCallbacks(iwb_fragment, XmNvalueChangedCallback);      /* BT 6/9/97 */
     XtAddCallback(iwb_fragment,XmNvalueChangedCallback,
		   GUI_Bernoulli_width_radio_toggle,iwb_fragment);

     iwb_shift = wid_toggleg(rowcol_tmp,0,
			   "Column Shift",
			   True,GUI_Bernoulli_width_radio_toggle,NULL,-1,-1);           
     XtRemoveAllCallbacks(iwb_shift, XmNvalueChangedCallback);      /* BT 6/9/97 */
     XtAddCallback(iwb_shift,XmNvalueChangedCallback,
		   GUI_Bernoulli_width_radio_toggle,iwb_shift);
     /* Width */
     iwb_width=wid_toggleg(rowcol_tmp,0,
			   "Vary Width",
			   FALSE,GUI_Bernoulli_width_radio_toggle,NULL,-1,-1);           
     XtRemoveAllCallbacks(iwb_width, XmNvalueChangedCallback);
     XtAddCallback(iwb_width,XmNvalueChangedCallback,
		   GUI_Bernoulli_width_radio_toggle,iwb_width);

     iwb_minmaxwidth = wid_textboxb(rowcol_tmp,0,
				  "Width Range:", "", 20);  /* BT 4/25/97 */
     XtUnmanageChild(XtParent(iwb_minmaxwidth));
	   
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);       /* BT 6/9/97 */
     if(strcmp((char*)data,"DNA") != 0)			/* BT 3/26/97 */
        iwb_Xnu=wid_toggleg(rowcol_tmp,0,
			 "Xnu",TRUE,GUI_Bernoulli_toggle,NULL,-1,-1);

     iwb_maximization=wid_toggleg(rowcol_tmp,0,
			      "Map maximization", FALSE,  	/* BT 3/19/97 */
			       GUI_Bernoulli_toggle,NULL,-1,-1);

     /*     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1);  */     /* BT 9/17/97 */
     /* iwb_EM=wid_toggleg(rowcol_tmp,0,
			"Expectation Maximization",FALSE,
			GUI_Bernoulli_toggle,NULL,-1,-1); */ /* BT 09/22/04 removed em option */


     iwb_subopt_output = wid_toggleg(rowcol_tmp,0,
			      "Output from suboptimal sampler", FALSE,
			       GUI_Bernoulli_toggle,NULL,-1,-1);   /* BT 3/19/97 */

     /*     iwb_display_site=wid_toggleg(rowcol_tmp,0,
			     "Display the sites for near optimal sampling",
			     FALSE,GUI_Bernoulli_toggle,NULL,-1,-1); */      /* BT 7/9/97 */

     /* button for stop and accept */
     rowcol_tmp=wid_rowcol(iwb_rowcol,'h',-1,-1); 
     butb_stop=wid_pushg(rowcol_tmp,0,"   Stop  ",
                         GUI_Bernoulli_stop,NULL,0,0);
     butb_accept=wid_pushg(rowcol_tmp,0,"  Accept  ",
                         GUI_Bernoulli_accept,data,0,0);

     XtManageChild(iw_Bernoulli);
     
}


 /************ accept button callback *********************************/

 void GUI_Bernoulli_accept(Widget iw_temp, caddr_t data, caddr_t call_data)
 {
  Model M;
  int i;
  int val;
  char cval[FILENAME_MAX];     /* BT 5/9/97 */
  char cval2[FILENAME_MAX];     /* BT 10/20/97 */
  char *string;
  char tempOutfile[FILENAME_MAX] = "out.result";     /* BT 9/24/97 */

  /* construct command line */
  GUI_argc=1;
  /* data file */
  string=XmTextGetString(iwb_inputfile);
  strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
  XtFree( string );
  GUI_strip_space(cval2);
  strcpy(GUI_argv[GUI_argc], cval2);
  GUI_argc++;
 
  /*motif length */
  string=XmTextGetString(iwb_motif_length);
  strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
  XtFree( string );
  GUI_strip_space(cval2);
  strcpy(GUI_argv[GUI_argc], cval2);
  GUI_argc++;

  /* Propagation - recursive sampling routine */
  if( XmToggleButtonGadgetGetState(iwb_propagation) )
    {
        strcpy(GUI_argv[GUI_argc],"-E");
	GUI_argc++;
	string=XmTextGetString(iwb_motif_number);
	strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
	XtFree( string );
	GUI_strip_space(cval2);
	if(strlen(cval2)>0)
	  {
	    strcpy(GUI_argv[GUI_argc],cval2);
	    GUI_argc++;
	  }
	else
	  {
	  strcpy(GUI_argv[GUI_argc], "5" );
	  GUI_argc++;
	  }
    }
  else
    {
      /* motif number  */
      string=XmTextGetString(iwb_motif_number);
      strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
      XtFree( string );
      GUI_strip_space(cval2);
      if(strlen(cval2)>0)
	{
	  strcpy(GUI_argv[GUI_argc],cval2);
	  GUI_argc++;
	}
    }  

  /* palindromic */
  if(strcmp((char*)data,"DNA")==0)
    {
      if(XmToggleButtonGadgetGetState(iwb_palindromic))
	{
	  /* incomplete!!!!!!!!!!! */
	  strcpy(GUI_argv[GUI_argc],"-R");
	  GUI_argc++;
          string=XmTextGetString(iwb_palindromic_list);		/* BT 2/10/97 */
	  strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
	  XtFree( string );
	  GUI_strip_space(cval2);
	  if( strlen( cval2 ) > 0 )
	    {
	      strcpy(GUI_argv[GUI_argc],cval2);   
	      GUI_argc++;
	    }
	}  
    }

  /* no Xnu */
   if(strcmp((char*)data,"DNA") != 0)				/* BT 3/26/97 */
   {
      if(!XmToggleButtonGadgetGetState(iwb_Xnu))
      {
         strcpy(GUI_argv[GUI_argc],"-x");
  	 GUI_argc++;
       }  
    }

  if(strcmp((char*)data,"DNA")==0)
    {
      /* collapse alphabet */
      if(XmToggleButtonGadgetGetState(iwb_collapse))
	{
	  strcpy(GUI_argv[GUI_argc],"-c");
	  GUI_argc++;
          string=XmTextGetString(iwb_collapsed_list);		/* BT 2/10/97 */
	  strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
	  XtFree( string );
	  if( strlen( cval2 ) > 0 )
	  {
  	     GUI_strip_space(cval2);
             strcpy(GUI_argv[GUI_argc],cval2);   
          }
          GUI_argc++;
	} 

      /* concentrate region */
      if(XmToggleButtonGadgetGetState(iwb_concentrate))
	{
	  strcpy(GUI_argv[GUI_argc],"-a");
	  GUI_argc++;
          string=XmTextGetString(iwb_concentrate_list);		/* BT 2/10/97 */
	  strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
	  XtFree( string );
	  if( strlen( cval2 ) > 0 )
	  {
  	     GUI_strip_space(cval2);
             strcpy(GUI_argv[GUI_argc],cval2);   
          }
          GUI_argc++;
        } 
    }

  /* near optimal cutoff */
  strcpy(GUI_argv[GUI_argc],"-C");GUI_argc++;
  XmScaleGetValue(iwb_cutoff_value,&val);
  sprintf(cval,"%f",(float)val/100.0);
  strcpy(GUI_argv[GUI_argc],cval);
  GUI_argc++;
 
  /* Nucleic Acid Alphabet */
  if(strcmp((char*)data,"DNA")==0)
    {
        strcpy(GUI_argv[GUI_argc],"-n");    
	GUI_argc++;
    } 
 
  /* plateau period */
  strcpy(GUI_argv[GUI_argc],"-p"); GUI_argc++;
  string = XmTextGetString(iwb_plateau_per);
  strcpy(GUI_argv[GUI_argc], string);       
  XtFree( string );
  GUI_argc++;

  /* adjust period */
  strcpy(GUI_argv[GUI_argc],"-j"); GUI_argc++;
  string = XmTextGetString(iwb_adjust_per);
  strcpy(GUI_argv[GUI_argc], string);       
  XtFree( string );
  GUI_argc++;

  /* initial seed */
  if(XmToggleButtonGadgetGetState(iwb_init_seed))
    {
        strcpy(GUI_argv[GUI_argc],"-s");GUI_argc++;
	strcpy(GUI_argv[GUI_argc],XmTextGetString(iwb_init_seed_val)); 
	GUI_argc++;
    }    

  /* number of seed */
  strcpy(GUI_argv[GUI_argc],"-S");GUI_argc++;
  string = XmTextGetString(iwb_num_Seed);
  strcpy(GUI_argv[GUI_argc], string);       
  XtFree( string );
  GUI_argc++;

  /* pseudo site weight */
  strcpy(GUI_argv[GUI_argc],"-W");GUI_argc++;
  XmScaleGetValue(iwb_pseudo_site_wt,&val);
  sprintf(cval,"%f",(float)val/100.);
  strcpy(GUI_argv[GUI_argc],cval);       
  GUI_argc++;

  /* pseudo count weight */
  strcpy(GUI_argv[GUI_argc],"-w");GUI_argc++;
  XmScaleGetValue(iwb_pseudo_cnt_wt,&val);
  sprintf(cval,"%f",(float)val/100.);
  strcpy(GUI_argv[GUI_argc],cval);       		/* BT 1/31/97 */
  GUI_argc++;

  /* maximum interation  */
  strcpy(GUI_argv[GUI_argc],"-i");GUI_argc++;
  string = XmTextGetString(iwb_iteration_num);   /* BT 10/20/97 */
  strcpy(GUI_argv[GUI_argc], string);       
  XtFree( string );
  GUI_argc++;

  /* output file  */
  if(XmToggleButtonGadgetGetState(iwb_out_file))
     {
        strcpy(GUI_argv[GUI_argc],"-o");
	GUI_argc++;
	string=XmTextGetString(iwb_out_file_name);		/* BT 1/27/97 */
	strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
	XtFree( string );
	GUI_strip_space(cval2);
	if( strlen( cval2 ) > 0 )
	   {
            strcpy(GUI_argv[GUI_argc],cval2);
	    strcpy( tempOutfile, cval2);                /* BT 9/24/97 */
	    GUI_argc++;
           }
        else
           {
	     strcpy( GUI_argv[GUI_argc], tempOutfile );
	     GUI_argc++;
           }   
     }    
 
  /* priors file  */
  if(XmToggleButtonGadgetGetState(iwb_priority_file))		/* BT 1/31/97 */
    {
        strcpy(GUI_argv[GUI_argc],"-P");
	GUI_argc++;
	string=XmTextGetString(iwb_priority_file_name);		/* BT 1/31/97 */
	strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
	XtFree( string );
	if( strlen( cval2 ) > 0 )
	{
  	   GUI_strip_space(cval2);
           strcpy(GUI_argv[GUI_argc],cval2);   GUI_argc++;
        }
       free(string);
    }    


  /* prior output file  */
  if(XmToggleButtonGadgetGetState(iwb_prout_file))		/* BT 9/29/97 */
    {
        strcpy(GUI_argv[GUI_argc],"-O");
	GUI_argc++;
	string=XmTextGetString(iwb_prout_file_name);		/* BT 1/31/97 */
	strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
	XtFree( string );
	GUI_strip_space(cval2);
	if( strlen( cval2 ) > 0 )
	  {
	    strcpy(GUI_argv[GUI_argc],cval2);   
	    GUI_argc++;
	  }
        else
	  {
	    strcpy( GUI_argv[GUI_argc], tempOutfile );
	    strcat( GUI_argv[GUI_argc], ".pr" );
	    GUI_argc++;
	  }
    }    


  /* scan file  */
  if(XmToggleButtonGadgetGetState(iwb_scan_file))		/* BT 9/17/97 */
    {
        strcpy(GUI_argv[GUI_argc],"-N");
	GUI_argc++;
	string=XmTextGetString(iwb_scan_file_name);		/* BT 1/31/97 */
	strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
	XtFree( string );
	GUI_strip_space(cval2);
	if( strlen( cval2 ) > 0 )
	  {
	    strcpy(GUI_argv[GUI_argc],cval2);   
	    GUI_argc++;
	  }
        else
	  {
	    strcpy( GUI_argv[GUI_argc], tempOutfile );
	    strcat( GUI_argv[GUI_argc], ".sn" );
	    GUI_argc++;
	  }
    }    

  /* display sites */  /* BT 7/9/97 */
  /*  if(XmToggleButtonGadgetGetState(iwb_display_site))     
    {
        strcpy(GUI_argv[GUI_argc],"-t");
	GUI_argc++;
    }
    */

  /* Overlap at End */
  if(strcmp((char*)data,"DNA")==0)		/* BT 4/23/97 */
  { 
     strcpy(GUI_argv[GUI_argc],"-v");GUI_argc++;
     XmScaleGetValue(iwb_overlap,&val);
     sprintf(cval,"%f",(float)val/100.0);
     strcpy(GUI_argv[GUI_argc],cval);
     GUI_argc++;
  } 

  /* turn off maximization*/
  if(!XmToggleButtonGadgetGetState(iwb_maximization))
    {
        strcpy(GUI_argv[GUI_argc],"-m");
	GUI_argc++;
    }

  /* turn on expectation maximization*/
  /* if(XmToggleButtonGadgetGetState(iwb_EM))
    {
        strcpy(GUI_argv[GUI_argc],"-e");
	GUI_argc++;
	} */ /* BT 09/22/04 */

  /* turn off fragmentation */
  if(!XmToggleButtonGadgetGetState(iwb_fragment))
    {
        strcpy(GUI_argv[GUI_argc],"-F");
	GUI_argc++;

    }
  /* turn width calculation */
  if(XmToggleButtonGadgetGetState(iwb_width))
    {
        strcpy(GUI_argv[GUI_argc],"-d");
	GUI_argc++;

	string = XmTextGetString( iwb_minmaxwidth );
	strncpy( cval2, string, sizeof( cval2 ) );    /* BT 10/20/97 */
	XtFree( string );
	GUI_strip_space(cval2);
        strcpy(GUI_argv[GUI_argc], cval2);
	GUI_argc++;
    }

  /* turn off revs revs cmpl */			
  if(strcmp((char*)data,"DNA")==0)				/* BT 2/3/97 */
     {  
     if(!XmToggleButtonGadgetGetState(iwb_revs_cmpl))		/* BT 1/31/97 */
       {
       strcpy(GUI_argv[GUI_argc],"-r");
       GUI_argc++;
       }
     }

  /* Check for Wilcoxon signed-rank test */                      /* BT 7/9/97 */
  if( XmToggleButtonGadgetGetState(iwb_wilcoxon) )
    {
      strcpy(GUI_argv[GUI_argc],"-l");
      GUI_argc++;
      string=XmTextGetString(iwb_wilcoxon_filename);		/* BT 1/28/98 */
      strncpy( cval2, string, sizeof( cval2 ) ); 
      XtFree( string );
      if( strlen( cval2 ) > 0 )
	{
	  GUI_strip_space(cval2);
	  if( strlen( cval2 ) > 0 )
	    {
	      strcpy(GUI_argv[GUI_argc],cval2);   
	      GUI_argc++;
	    }
        }
      free(string);
    }

  /* Check for sampling along length */                      /* BT 9/10/97 */
  if( XmToggleButtonGadgetGetState(iwb_lensample) )
    {
      strcpy(GUI_argv[GUI_argc],"-g");
      GUI_argc++;
    }
 
  /* Check spacing model */
  if( XmToggleButtonGadgetGetState(iwb_ignorespacing) )   /* BT 6/10/98 */
    {
      strcpy(GUI_argv[GUI_argc],"-z");
      GUI_argc++;
    }

  /* check for subopt sampler display */			/* BT 3/19/97 */
  if( XmToggleButtonGadgetGetState(iwb_subopt_output) )
  {
     strcpy(GUI_argv[GUI_argc],"-u");
     GUI_argc++;
  }


  /* close the option window */
  XtUnmanageChild(iw_Bernoulli);
  XFlush(idispl);
  XmUpdateDisplay(toplevel);     /* BT 6/17/97 */

  /* call the main function of Bernoulli */ 

  M = alloc_Model();
  if( ! stripargs(GUI_argc, GUI_argv, M, TRUE) ) /* Get arguments from command line */
     return;						/* BT 3/21/97 */
  get_inputs(M);

  if( M->IP->is_defined[cl_l] ) 
    Wilcoxon( M );
  else
    get_strings(M);           /* Read the sequences */
  
  InitRProbStruct( M );
  
  alloc_Counts(M);
  set_counts(M);                             /* Set the initial counts */
  set_posterior_prob(M->IP, M->First);       /* Set initial posterior prob */
  *M->Seq->ProcessedSTR = Xnu_Sequence(M);   /* preprocess the sequence */

  set_pseudo_counts(M, M->IP, M->First);        /* Set initial pseudo counts  */

#ifndef _MPI_  
     print_options( M );		/* BT 1/27/97 */
     PrintSeqDescriptions( M );
#endif     

  if( M->IP->is_defined[cl_B] )
    ReadBkgndComposition( M, M->First );

  if( M->IP->is_defined[cl_U] )
    ReadSpacingFile( M, M->IP->Datafiles->spacing_fpt );

  if(M->IP->Datafiles->weight_fpt != NULL)      
    ReadWeightFile( M );

  CalcAlignProbFromFootprint( M );
  
  find_best_sites(M);                        /* find maximal alignment     */
  FreeData(M);
 }

/*************** toggle button click *********************************/
/* void GUI_Bernoulli_toggle(Widget parent, caddr_t data, caddr_t call_data) */
void GUI_Bernoulli_toggle(Widget parent, void *data, void *call_data)  /* BT 12/09/99 */
{
  Widget tmp=(Widget) data;

  if(tmp!=NULL)
    {
      if(XmToggleButtonGadgetGetState(parent))
	{
	  /* pop up the following widget */
	  XtManageChild(XtParent(tmp));
	}
      else
	{
	  /* pop down the following widget */
	  XtUnmanageChild(XtParent(tmp));
	}
    }

}

/* BT 6/9/97 */
/*************** toggle button click *********************************/
void GUI_Bernoulli_width_radio_toggle(Widget parent, void *data, void *call_data)
{
  char *string;
  char cval[256];
  char cval2[256];
  int  values[30];
  int  cnt;
  int  minWidth;
  int  maxWidth;
  int  i;

  Widget tmp=(Widget) data;

  if(tmp!=NULL)
    {
      XmToggleButtonSetState( iwb_fragment, FALSE, FALSE );
      XmToggleButtonSetState( iwb_width, FALSE, FALSE );
      XmToggleButtonSetState( iwb_shift, FALSE, FALSE );
      XmToggleButtonSetState( tmp, TRUE, FALSE );

      if( XmToggleButtonGadgetGetState(iwb_width) )
	{
	  XtManageChild(XtParent(iwb_minmaxwidth));	  
	  string = XmTextGetString( iwb_minmaxwidth );
	  if( strlen( string ) == 0 )
	    {
	      string = XmTextGetString( iwb_motif_length );
	      strncpy( cval2, string, sizeof( cval2 ) );     /* BT 10/20/97 */
	      XtFree( string );
	      GUI_strip_space(cval2);
	      if( strlen( cval2 ) > 0 )
		{
		  cval[0] = '\0';
		  cnt = ParseIntegers( cval2, values, "Getting Widths" );
		  for( i = 0; i < cnt; i++ )
		    {
		      if( i > 0 )
			sprintf( &cval[strlen(cval)], ", " );     /* BT 11/26/97 */
		      sprintf( &cval[strlen(cval)], "%d,%d,%d", 
			       i + 1, values[i+1] - values[i+1] / 4, values[i+1] + values[i+1] / 4);
		    }
		  XmTextSetString( iwb_minmaxwidth, cval );  
		}
	    }
	  else
	    XtFree( string );
	}
      else
	{
	  XtUnmanageChild(XtParent(iwb_minmaxwidth));	  
	}
    }
}


/* BT 2/9/98 */
/*************** Recursion toggle button click *********************************/
void GUI_Bernoulli_propagation_toggle(Widget parent, caddr_t data, caddr_t call_data)
{
  Widget tmp=(Widget) data;

  if(XmToggleButtonGadgetGetState(parent))
    {
      XmToggleButtonSetState( iwb_maximization, FALSE, FALSE );
      XtSetSensitive(iwb_maximization, FALSE);
      /* XmToggleButtonSetState( iwb_EM, FALSE, FALSE ); 
      /* XtSetSensitive(iwb_EM, FALSE); */ /* BT 09/22/04 */
      /*      XmToggleButtonSetState( iwb_fragment, FALSE, FALSE );
      XtSetSensitive(iwb_fragment, FALSE); */                /* BT 9/9/98 */
      XtSetSensitive(iwb_ignorespacing, TRUE);
    }
  else
    {
      XtSetSensitive(iwb_maximization, TRUE);
      /* XtSetSensitive(iwb_EM, TRUE); */ /* BT 09/22/04 */
      /*  XtSetSensitive(iwb_fragment, TRUE); */                /* BT 9/9/98 */
      XmToggleButtonSetState( iwb_ignorespacing, FALSE, FALSE );
      XtSetSensitive(iwb_ignorespacing, FALSE);
    }
}


 /************ stop button callback *********************************/

 void GUI_Bernoulli_stop(Widget iw_temp, caddr_t data, caddr_t call_data)
 {


      XtUnmanageChild(iw_Bernoulli);  


 }


















