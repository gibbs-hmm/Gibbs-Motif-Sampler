/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/
/*******************************************************************/
/*                                                                 */
/* $Id: Sankoff.c,v 1.4 2007/05/23 18:19:55 Bill Exp $   */
/*                                                                 */
/* Author: Jun Zhu 1996/7/15                                       */
/*                                                                 */
/*                                                                 */
/*  Sankoff method: for detail read David Sankoff's paper in       */
/*  Proc.Nat.Acad.Sci.USA Vol. 69, No.1, pp. 4-6, Jan. 1972        */
/*  This is not strick Sankoff method, it is Sankoff-like method.  */
/*  It uses the Sankoff_blocks as the limit of matching blocks.    */
/*                                                                 */
/*******************************************************************/

#include <limits.h>
#include <math.h>
#include "common.h"
#include "blosum.h"
#include "blosum_ni.h"
#include "Sankoff.h"
#include "mem_mgmt.h"

/* subroutines define here */ 
void Sankoff_Back_Sampling(Model,Sank_S);
void Sankoff_Back_Sampling_cutoff(Model,Sank_S);
void Sankoff_Bayesain_align(Model B, Sank_S SK);
void Sankoff_Make_S(Stype, Sank_S);
void Sankoff_probability_N(Model,Sank_S);
void Sankoff_probability_W(Model,Sank_S);
void Sankoff_Trace_S(Model, Sank_S);
float SA(short**,float**, float**,int, int,int,Sank_S);
float SB(short**,float**, int, int,int*,int,Sank_S);
double SC(Model,Sank_S,int);
int max3(int,int,int);

void Sankoff(Model B,Sank_S SK)
{

     register int i,j,k,n;     /* general register */
     int Nmatrix,matrix_num;
     int **s_pptr,*s_ptr;      /* pointer for quick access matrix */
     short *x_ptr;
     float sump;               /* sum of posterior probability */
     SimTime time;
     float posterior;

     BeginTime(&time);
     Nmatrix=SK->Nmatrix;

     /* allocate space for Sankoff structure                   */
     /* as the space complexity is high, we can allocate some  */
     /* space at a time, then release if they are not needed.  */

     alloc_Sank(B,SK);          /* allocate basic memory  */   
     alloc_Sank_WN(B,SK);       /* allocate memory for W* and N* */
     Sankoff_probability_N(B,SK);
     free_Sank_N(B,SK);
     Sankoff_probability_W(B,SK); 
     if(!SK->flags.back_sampling)
         free_Sank_W(B,SK);

     if(SK->flags.best_alignment){ /* calculate the best alignment */
         alloc_Sank_S(B,SK);       /* allocate memory for S */
         Sankoff_Make_S(B->Seq,SK);     
	 Sankoff_Trace_S(B,SK); 
	 if(!SK->flags.back_sampling || !SK->flags.back_sampling_cutoff)
	     free_Sank_S(B,SK);
     }
     else{ /* just print out maginal likelihood */
         fprintf(B->IP->Datafiles->out_fpt,"\n");
	 for(n=0;n<Nmatrix;n++){
	     if(Nmatrix>1){/* multiple matrices */
	         matrix_num=n;
	     }
	     else{
	         matrix_num=SK->matrix_num;
	     }
	     fprintf(B->IP->Datafiles->out_fpt,
		     "Matrix #%d\n",matrix_num);
	     for(k=1;k<=SK->Sankoff_blocks;k++){
	         fprintf(B->IP->Datafiles->out_fpt,
			 "k=%d, W[k]=%g, N[k]=%g, W[k]/N[k]=%g\n",
			 k,SK->W[n][k],SK->N[k],SK->W[n][k]/SK->N[k]);
		 /* posterior of k>0 */
		 posterior=0;
		 for(i=1;i<=k;i++)
		     posterior+=SK->W[n][i]/SK->N[i];
		 posterior=posterior/(float)k;
		 fprintf(B->IP->Datafiles->out_fpt,
			 "P(k>0|R)=%g\n\n",posterior/(1.+posterior));	  
	     }
	 }
	 if(SK->Nmatrix>1){ /* print posterior P(k|R) and P(psi|R) */
	     fprintf(B->IP->Datafiles->out_fpt,"\n\n P(k|R)\n");	
	     sump=0;
	     for(i=0;i<=SK->Sankoff_blocks;i++){
	         sump+=SK->PK[i];
	         fprintf(B->IP->Datafiles->out_fpt,
			 "P(%d|R)=%g, P(k>%d|R)=%g\n", 
			 i,SK->PK[i],i,1.-sump);	
	     }
	     fprintf(B->IP->Datafiles->out_fpt,"\n\n P(psi|R)\n");	
	     for(n=0;n<SK->Nmatrix;n++){
	         fprintf(B->IP->Datafiles->out_fpt,"P(%d|R)=%g\n",
			 n,SK->PSI[n]);	
	     }	 
	 }    
     }
     if(SK->flags.back_sampling){
	 Sankoff_Back_Sampling(B,SK);
	 if(SK->flags.best_alignment && SK->flags.back_sampling_cutoff){
	     Sankoff_Back_Sampling_cutoff(B,SK);
	     free_Sank_S(B,SK);
	 }
	 free_Sank_W(B,SK);
     }

     free_Sank(B,SK);

     if(B->IP->Datafiles->out_fpt!=stdout) fclose(B->IP->Datafiles->out_fpt);
     free(B->IP->nPossSites);
     free(B->Seq->SeqLen);
     for(i=0;i<=19;i++){
	 free(B->Seq->Orig[i]);
	 i++;
     }
     free(B->Seq->Orig);
     free(B->Seq->R[0]);
     free(B->Seq->nvEndLocs[0]);
     free(B->IP);
     free(B);
     EndTime(&time, stdout );
}

/*******************  Sankoff_Back_Sampling ************************/
/*                                                                 */
/*  Back Sampling the alignment                                    */
/*  The results are saved in SK->start_x[0][k], and                */
/*  SK->end_x[0][k]                                                */
/*******************************************************************/

void Sankoff_Back_Sampling (Model B, Sank_S SK)
{

  int i,j,k,n,N;
  int start_x,start_y;
  int Nmatrix,matrix_num;
  short* profile_ptr;          /* for quick access */
  float score;
  int Nblocks;
  int *Nback_sampling;         /* number of sample drawed for each matrix */
  double tmp,tmp1,w;
  double ***WC,***WD,***WR;    /* for quick access */
  double **wd_pptr,**wd_pptr0;   /* for quick access */
  double **wc_pptr;    
  double **wr_pptr,**wr_pptr0;
  enum {DOWN, CENTRAL,RIGHT} last_step;
  char filename[80];
  FILE* profile_fptr;
  Stype Seq=B->Seq;



  Nmatrix=SK->Nmatrix;
  NEW(Nback_sampling,Nmatrix,int);
  /* allocate space for profile */
  NEWP(SK->profile,Seq->SeqLen[0]+1 ,short);
  for(i=0;i<=Seq->SeqLen[0];i++){
      NEW(SK->profile[i],Seq->SeqLen[1]+1,short);
  }
  /* initialize the profile */
  for(i=0;i<=Seq->SeqLen[0];i++){
      profile_ptr=SK->profile[i];
      for(j=0;j<=Seq->SeqLen[1];j++){
	  profile_ptr[j]=0;
      }
  }

  /* set seed */
  sRandom( B, (long)time(NULL));

  fprintf(B->IP->Datafiles->out_fpt,"Back sampling.\n\n");
  if(Nmatrix>1){/* multiple matrices, sampling according to P(psi|R)*/
      for(N=0;N<Nmatrix;N++){
	  Nback_sampling[N]=(int)(SK->backsampling_number*SK->PSI[N]);
      }
  }
  else{
      Nback_sampling[0]=SK->backsampling_number;
  }

  for(N=Nmatrix-1;N>=0;N--){
      if(Nmatrix>1){/* multiple matrices */
	  matrix_num=N;
      }
      else{
	  matrix_num=SK->matrix_num;
      }

      if(N!=Nmatrix-1){/* need to recalculate the WC, WR,WD */
	  for(k=1;k<=SK->Sankoff_blocks;k++){
	      wd_pptr=SK->WD[0][k];
	      wd_pptr0=SK->WD[0][k-1];
	      wr_pptr=SK->WR[0][k];
	      wr_pptr0=SK->WR[0][k-1];
	      wc_pptr=SK->WC[0][k];

	      for(i=1;i<=Seq->SeqLen[0];i++){
		  for(j=1;j<=Seq->SeqLen[1];j++){
		      wd_pptr[i][j]=wc_pptr[i-1][j]+wd_pptr[i-1][j];
		      wr_pptr[i][j]=wc_pptr[i][j-1]+wd_pptr[i][j-1]+
		            wr_pptr[i][j-1];
		      wc_pptr[i][j]=(wd_pptr0[i-1][j-1]+wr_pptr0[i-1][j-1]+
			     wc_pptr[i-1][j-1])*SK->P[N][i][j];
		  }
	      }
	  }
      }

      WC=SK->WC[0];
      WR=SK->WR[0];
      WD=SK->WD[0];

      fprintf(B->IP->Datafiles->out_fpt,"%d samples are from Matrix #%d.\n\n",
	      Nback_sampling[N],N);
      for(i=0;i<Nback_sampling[N];i++){
	  if(SK->backsampling_blocks>SK->Sankoff_blocks){
	      /* sampling with random number of blocks according MagL */
	      /* get a random number between 0-1 */
	      tmp=Random()/(double)INT32_MAX;
	      tmp1=SK->PKSI[N][1];
	      k=1;
	      while(k<SK->Sankoff_blocks && tmp1<tmp){
		  k++;
		  tmp1+=SK->PKSI[N][k];
	      }
	      Nblocks=k;
	  }
	  else{/* sampling with fix number of blocks */
	      Nblocks=SK->backsampling_blocks;
	  }

	  /* initializing */
	  for(k=1;k<=Nblocks;k++)
	      SK->start_x[0][k]=0;

	  start_x=B->Seq->SeqLen[0];
	  start_y=B->Seq->SeqLen[1];
	  k=Nblocks;
	  score=0;
	  last_step=RIGHT;

	  while(start_x >0 && start_y >0 && k>0){
	      /* get a random number between 0-1 */
	      tmp=Random()/(double)INT32_MAX;
	   
	      switch(last_step){
	      case DOWN:
		  w=WC[k][start_x][start_y]+
		    WD[k][start_x][start_y];	      
		  if(WC[k][start_x][start_y]/w >tmp){ 
		      /* take the center path */
		      score=score+f_related[matrix_num]
		                       [B->Seq->Orig[0][start_x-1]]
		                       [B->Seq->Orig[1][start_y-1]];

		      
		      SK->end_x[0][k]=start_x;
		      SK->end_y[0][k]=start_y;
		      SK->start_x[0][k]=start_x;
		      SK->start_y[0][k]=start_y;
		      start_x--;
		      start_y--;
		      last_step=CENTRAL;
		  }
		  else {/* go up */
		      start_x--;
		      last_step=DOWN;		  
		  }
		  break;
	      
	      case CENTRAL:
		  w=WC[k][start_x][start_y]+
		    WR[k-1][start_x][start_y]+
		    WD[k-1][start_x][start_y];
		  if(WC[k][start_x][start_y]/w >tmp){ 
		      /* take the center path */
		      score=score+f_related[matrix_num]
		                       [B->Seq->Orig[0][start_x-1]]
		                       [B->Seq->Orig[1][start_y-1]];

		      
		      SK->start_x[0][k]=start_x;
		      SK->start_y[0][k]=start_y;
		      start_x--;
		      start_y--;
		      last_step=CENTRAL;
		  }
		  else if((WC[k][start_x][start_y]+
			   WR[k-1][start_x][start_y])/w >tmp){
		      /* take a path to go left */
		      start_y--;
		      k--;
		      last_step=RIGHT;
		  }
		  else{ /* go up */
		      start_x--;
		      k--;
		      last_step=DOWN;		  
		  }
		  break;

	      case RIGHT:
		  w=WC[k][start_x][start_y]+
		    WR[k][start_x][start_y]+
		    WD[k][start_x][start_y];	      
		  if(WC[k][start_x][start_y]/w >tmp){
		      /* take the center path */
		      score=score+f_related[matrix_num]
		                       [B->Seq->Orig[0][start_x-1]]
		                       [B->Seq->Orig[1][start_y-1]];	      
		      SK->end_x[0][k]=start_x;
		      SK->end_y[0][k]=start_y;
		      SK->start_x[0][k]=start_x;
		      SK->start_y[0][k]=start_y;
		      start_x--;
		      start_y--;
		      last_step=CENTRAL;
		  }
		  else if((WC[k][start_x][start_y]+
			   WR[k][start_x][start_y])/w > tmp){
		      /* take a path to the left */
		      start_y--;
		      last_step=RIGHT;
		  }
		  else {/* go up */
		      start_x--;
		      last_step=DOWN;		  
		  }
		  break;
	      }
	  }
	  /* print the score */
	  fprintf(B->IP->Datafiles->out_fpt,"k= %d , score= %3f\n",
		  Nblocks,score);
	  /* set profile */
	  for(k=1;k<=Nblocks;k++){
	      if(SK->start_x[0][k]!=0){/* find a block */
		  for(n=SK->start_x[0][k],j=SK->start_y[0][k];
		      n<=SK->end_x[0][k];n++,j++){
		      SK->profile[n][j]++;
		  }	
	      }
	  }
	  /* out put the matching string */
	  if(SK->flags.back_sampling_sequence){
	      for(k=1;k<=Nblocks;k++){
		  if(SK->start_x[0][k]!=0){
		      fprintf(B->IP->Datafiles->out_fpt,"%3d ",
			      SK->start_x[0][k]); 
		      for(n=SK->start_x[0][k];n<=SK->end_x[0][k];n++){
			  fprintf(B->IP->Datafiles->out_fpt,"%c",
				  (char )(SEQ2CH(Seq->Orig[0][n-1])+65)); 
		      }
		      fprintf(B->IP->Datafiles->out_fpt,"% 3d\n",
			      SK->end_x[0][k]);
		      fprintf(B->IP->Datafiles->out_fpt,"%3d ",
			      SK->start_y[0][k]); 
		      for(n=SK->start_y[0][k];n<=SK->end_y[0][k];n++){
			  fprintf(B->IP->Datafiles->out_fpt,"%c",
				  (char )(SEQ2CH(Seq->Orig[1][n-1])+65)); 
		      }
		      fprintf(B->IP->Datafiles->out_fpt,"% 3d\n",
			      SK->end_y[0][k]);
		      fprintf(B->IP->Datafiles->out_fpt,"\n");
		  }	
		  else{
		      fprintf(B->IP->Datafiles->out_fpt,"No matching.\n\n");
		  }
	      }
	  }
      }
  }
  /* open a file name as "input.profile" */
  strcpy(filename,B->IP->Datafiles->filename);
  strcat(filename,".profile");
  profile_fptr=fopen(filename,"w");
  for(i=1;i<=Seq->SeqLen[0];i+=2){
      for(j=1;j<=Seq->SeqLen[1];j++){
	  fprintf(profile_fptr,"%d %d %d\n",i,j,SK->profile[i][j]);
      }
      fprintf(profile_fptr,"\n\n");      
  }
  fclose(profile_fptr);
  /* find the Bayesain alignment */
  Sankoff_Bayesain_align(B,SK);

  /* free the profile */
  for(i=0;i<=Seq->SeqLen[0];i++){
      free(SK->profile[i]);
  }
  free(SK->profile);

}
/*******************  Sankoff_Back_Sampling_cutoff *****************/
/*                                                                 */
/*  Back Sampling the alignment                                    */
/*******************************************************************/

void Sankoff_Back_Sampling_cutoff (Model B, Sank_S SK)
{

  int i,k,n;
  int Nblocks; 
  double sumS, Ln2=log(2);
  enum Last_step {DOWN, CENTRAL,RIGHT};
  struct Sank_BS_Cutoff_node{
    enum Last_step last_step;
    float     score;                 /* score from the end to this node */
    int       k;                     /* number of block from the start  */
				     /* to this blocks                  */
    int       i,j;                   /* current position                */
    int       *start_x,*start_y;     /* starts of matching segments     */
    int       *end_x,*end_y;         /* ends of matching segments       */
    struct Sank_BS_Cutoff_node *last;/* address for the last one        */
  };
  typedef struct Sank_BS_Cutoff_node Sank_BS_Cutoff_node;
  Sank_BS_Cutoff_node  *current_node,*node_tmp;
  struct {
    Sank_BS_Cutoff_node *header;
    int                 num;
  } node_list;
  Stype Seq=B->Seq;                  /* for quick access                */


  fprintf(B->IP->Datafiles->out_fpt,
	  "Back sampling above cutoff=%f.\n\n",SK->backsampling_cutoff_value);

  sumS=0;
  Nblocks=SK->backsampling_blocks;

  /* set up the first  node */
  NEW(node_tmp,1,Sank_BS_Cutoff_node);
  NEW(node_tmp->start_x,Nblocks+1,int);
  NEW(node_tmp->start_y,Nblocks+1,int);
  NEW(node_tmp->end_x,Nblocks+1,int);
  NEW(node_tmp->end_y,Nblocks+1,int);
  node_tmp->last_step=RIGHT;
  node_tmp->score=0;
  node_tmp->k=Nblocks;
  node_tmp->i=Seq->SeqLen[0];
  node_tmp->j=Seq->SeqLen[1];
  node_tmp->last=NULL;

  node_list.header=node_tmp;
  node_list.num=1;

  while(node_list.num >0)
    {
      /* pop up a node */
      current_node=node_list.header;
      node_list.header=node_list.header->last;
      node_list.num--;

      if(current_node->score+
	 SK->S[0][current_node->k][current_node->i][current_node->j]>=
	 SK->backsampling_cutoff_value)
	{ /* explore this node */
	  if(current_node->i >0 && current_node->j >0 && 
	     current_node->k>0)
	    { /* explore this node */
	      switch(current_node->last_step)
		{
		case DOWN: /* two choices */
		  /* path to go up */
		  NEW(node_tmp,1,Sank_BS_Cutoff_node);
		  NEW(node_tmp->start_x,Nblocks+1,int);
		  NEW(node_tmp->start_y,Nblocks+1,int);
		  NEW(node_tmp->end_x,Nblocks+1,int);
		  NEW(node_tmp->end_y,Nblocks+1,int);
		  memcpy(node_tmp->start_x,current_node->start_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->start_y,current_node->start_y,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_x,current_node->end_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_y,current_node->end_y,
			 sizeof(int)*(Nblocks+1));
		  node_tmp->last_step=DOWN;
		  node_tmp->score=current_node->score;
		  node_tmp->k=current_node->k;
		  node_tmp->i=current_node->i-1;
		  node_tmp->j=current_node->j;
		  node_tmp->last=node_list.header;
		  node_list.header=node_tmp;
		  node_list.num++;

		  /* path central */
		  NEW(node_tmp,1,Sank_BS_Cutoff_node);
		  NEW(node_tmp->start_x,Nblocks+1,int);
		  NEW(node_tmp->start_y,Nblocks+1,int);
		  NEW(node_tmp->end_x,Nblocks+1,int);
		  NEW(node_tmp->end_y,Nblocks+1,int);
		  memcpy(node_tmp->start_x,current_node->start_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->start_y,current_node->start_y,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_x,current_node->end_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_y,current_node->end_y,
			 sizeof(int)*(Nblocks+1));
		  node_tmp->last_step=CENTRAL;
		  node_tmp->score=current_node->score+
		    f_related[SK->matrix_num][Seq->Orig[0][current_node->i-1]]
		           [Seq->Orig[1][current_node->j-1]];
		  node_tmp->k=current_node->k;
		  node_tmp->i=current_node->i-1;
		  node_tmp->j=current_node->j-1;
		  node_tmp->end_x[current_node->k]=current_node->i;	
		  node_tmp->end_y[current_node->k]=current_node->j;
		  node_tmp->start_x[current_node->k]=current_node->i;
		  node_tmp->start_y[current_node->k]=current_node->j;	  
		  node_tmp->last=node_list.header;
		  node_list.header=node_tmp;
		  node_list.num++;
		  break;
	      
		case CENTRAL: /* three choice */
		  /* take the center path */
		  NEW(node_tmp,1,Sank_BS_Cutoff_node);
		  NEW(node_tmp->start_x,Nblocks+1,int);
		  NEW(node_tmp->start_y,Nblocks+1,int);
		  NEW(node_tmp->end_x,Nblocks+1,int);
		  NEW(node_tmp->end_y,Nblocks+1,int);
		  memcpy(node_tmp->start_x,current_node->start_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->start_y,current_node->start_y,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_x,current_node->end_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_y,current_node->end_y,
			 sizeof(int)*(Nblocks+1));
		  node_tmp->last_step=CENTRAL;
		  node_tmp->score=current_node->score+
		    f_related[SK->matrix_num][Seq->Orig[0][current_node->i-1]]
		           [Seq->Orig[1][current_node->j-1]];
		  node_tmp->k=current_node->k;
		  node_tmp->i=current_node->i-1;
		  node_tmp->j=current_node->j-1;
		  node_tmp->start_x[current_node->k]=current_node->i;	
		  node_tmp->start_y[current_node->k]=current_node->j;
		  node_tmp->last=node_list.header;
		  node_list.header=node_tmp;
		  node_list.num++;

		  /* take a path to go left */
		  NEW(node_tmp,1,Sank_BS_Cutoff_node);
		  NEW(node_tmp->start_x,Nblocks+1,int);
		  NEW(node_tmp->start_y,Nblocks+1,int);
		  NEW(node_tmp->end_x,Nblocks+1,int);
		  NEW(node_tmp->end_y,Nblocks+1,int);
		  memcpy(node_tmp->start_x,current_node->start_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->start_y,current_node->start_y,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_x,current_node->end_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_y,current_node->end_y,
			 sizeof(int)*(Nblocks+1));
		  node_tmp->last_step=RIGHT;
		  node_tmp->score=current_node->score;
		  node_tmp->k=current_node->k-1;
		  node_tmp->i=current_node->i;
		  node_tmp->j=current_node->j-1;	
		  node_tmp->last=node_list.header;
		  node_list.header=node_tmp;
		  node_list.num++;

		  /* go up */
		  NEW(node_tmp,1,Sank_BS_Cutoff_node);
		  NEW(node_tmp->start_x,Nblocks+1,int);
		  NEW(node_tmp->start_y,Nblocks+1,int);
		  NEW(node_tmp->end_x,Nblocks+1,int);
		  NEW(node_tmp->end_y,Nblocks+1,int);
		  memcpy(node_tmp->start_x,current_node->start_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->start_y,current_node->start_y,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_x,current_node->end_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_y,current_node->end_y,
			 sizeof(int)*(Nblocks+1));
		  node_tmp->last_step=DOWN;
		  node_tmp->score=current_node->score;
		  node_tmp->k=current_node->k-1;
		  node_tmp->i=current_node->i-1;
		  node_tmp->j=current_node->j;		  
		  node_tmp->last=node_list.header;
		  node_list.header=node_tmp;
		  node_list.num++;
		  break;

		case RIGHT: /* three choice */
		  /* take the center path */
		  NEW(node_tmp,1,Sank_BS_Cutoff_node);
		  NEW(node_tmp->start_x,Nblocks+1,int);
		  NEW(node_tmp->start_y,Nblocks+1,int);
		  NEW(node_tmp->end_x,Nblocks+1,int);
		  NEW(node_tmp->end_y,Nblocks+1,int);
		  memcpy(node_tmp->start_x,current_node->start_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->start_y,current_node->start_y,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_x,current_node->end_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_y,current_node->end_y,
			 sizeof(int)*(Nblocks+1));
		  node_tmp->last_step=CENTRAL;
		  node_tmp->score=current_node->score+
		    f_related[SK->matrix_num][Seq->Orig[0][current_node->i-1]]
		           [Seq->Orig[1][current_node->j-1]];
		  node_tmp->k=current_node->k;
		  node_tmp->i=current_node->i-1;
		  node_tmp->j=current_node->j-1;
		  node_tmp->end_x[current_node->k]=current_node->i;	
		  node_tmp->end_y[current_node->k]=current_node->j;
		  node_tmp->start_x[current_node->k]=current_node->i;
		  node_tmp->start_y[current_node->k]=current_node->j;
		  node_tmp->last=node_list.header;
		  node_list.header=node_tmp;
		  node_list.num++;

		  /* take a path to the left */
		  NEW(node_tmp,1,Sank_BS_Cutoff_node);
		  NEW(node_tmp->start_x,Nblocks+1,int);
		  NEW(node_tmp->start_y,Nblocks+1,int);
		  NEW(node_tmp->end_x,Nblocks+1,int);
		  NEW(node_tmp->end_y,Nblocks+1,int);
		  memcpy(node_tmp->start_x,current_node->start_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->start_y,current_node->start_y,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_x,current_node->end_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_y,current_node->end_y,
			 sizeof(int)*(Nblocks+1));
		  node_tmp->last_step=RIGHT;
		  node_tmp->score=current_node->score;
		  node_tmp->k=current_node->k;
		  node_tmp->i=current_node->i;
		  node_tmp->j=current_node->j-1;
		  node_tmp->last=node_list.header;
		  node_list.header=node_tmp;
		  node_list.num++;

		  /* go up */
		  NEW(node_tmp,1,Sank_BS_Cutoff_node);
		  NEW(node_tmp->start_x,Nblocks+1,int);
		  NEW(node_tmp->start_y,Nblocks+1,int);
		  NEW(node_tmp->end_x,Nblocks+1,int);
		  NEW(node_tmp->end_y,Nblocks+1,int);
		  memcpy(node_tmp->start_x,current_node->start_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->start_y,current_node->start_y,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_x,current_node->end_x,
			 sizeof(int)*(Nblocks+1));
		  memcpy(node_tmp->end_y,current_node->end_y,
			 sizeof(int)*(Nblocks+1));
		  node_tmp->last_step=DOWN;
		  node_tmp->score=current_node->score;
		  node_tmp->k=current_node->k;
		  node_tmp->i=current_node->i-1;
		  node_tmp->j=current_node->j;
		  node_tmp->last=node_list.header;
		  node_list.header=node_tmp;
		  node_list.num++;
		  break;
		} /* end of switch block */
	    }
	  else /* not explore this node */
	    {
	      /* make sure do not report same alignment multiple time */
	      if(current_node->score >=SK->backsampling_cutoff_value &&
		 (current_node->k==0 && current_node->last_step==RIGHT))
		{ /* report the alignment */
		  fprintf(B->IP->Datafiles->out_fpt,"score=% 3f\n",
			  current_node->score);
		  sumS=sumS+exp(current_node->score/2.*Ln2);
		  /* out put the matching string */
		  if(SK->flags.back_sampling_sequence)
		    {
		      for(k=1;k<=Nblocks;k++)
			{	    
			  if(current_node->start_x[k]!=0)
			    {
			      fprintf(B->IP->Datafiles->out_fpt,"%3d ",
				      current_node->start_x[k]); 
			      for(n=current_node->start_x[k];
				  n<=current_node->end_x[k];n++)
				{
				  fprintf(B->IP->Datafiles->out_fpt,"%c",
				   (char )(SEQ2CH(Seq->Orig[0][n-1])+65)); 
				}
			      fprintf(B->IP->Datafiles->out_fpt,"% 3d\n",
				     current_node->end_x[k]);
			      fprintf(B->IP->Datafiles->out_fpt,"%3d ",
				      current_node->start_y[k]); 
			      for(n= current_node->start_y[k];
				  n<= current_node->end_y[k];n++)
				{
				  fprintf(B->IP->Datafiles->out_fpt,"%c",
				  (char )(SEQ2CH(Seq->Orig[1][n-1])+65)); 
				}
			      fprintf(B->IP->Datafiles->out_fpt,"% 3d\n",
				       current_node->end_y[k]);
			      fprintf(B->IP->Datafiles->out_fpt,"\n");
			    }			  
		  
			} /* end of for block */
		    } /* end of if(SK->flags.back_sampling_sequence) */

		} /*end of if(current_node->score >=SK->backsampling_cutoff)*/
	    } /* end of else block */

	}
      /* release the space for current node */
      free(current_node->end_x);
      free(current_node->end_y);
      free(current_node->start_x);
      free(current_node->start_y);
      free(current_node);
    }/* end of while node */

  fprintf(B->IP->Datafiles->out_fpt,"SumS(S>=%4f,k=%d)/N[%d]=%g  ",
	  SK->backsampling_cutoff_value,
	  SK->backsampling_blocks,
	  SK->backsampling_blocks,
	  sumS/SK->N[SK->backsampling_blocks]);

  fprintf(B->IP->Datafiles->out_fpt,"SumS(S>=%4f,k=%d)/W[%d]=%g\n",
	  SK->backsampling_cutoff_value,
	  SK->backsampling_blocks,
	  SK->backsampling_blocks,
	  sumS/SK->W[0][SK->backsampling_blocks]);

}

/********** Sankoff_Bayesain_align(Model B,Sank_S SK) **************/
/*                                                                 */
/*  Find the alignment according to joint probability              */
/*******************************************************************/

void Sankoff_Bayesain_align(Model B, Sank_S SK)
{

  int i,j,k;
  int i1,i2,j1,j2,pos;
  int max,max_i,max_j;
  int Nblocks;
  char filename[80];
  FILE *align_fptr;
  int *x_start,*x_end,*y_start,*y_end;

  Nblocks=SK->Sankoff_blocks;
  /* allocate space for ends of aligned segments */
  NEW(x_start,Nblocks+1,int);
  NEW(x_end,Nblocks+1,int);
  NEW(y_start,Nblocks+1,int);
  NEW(y_end,Nblocks+1,int);

  /* output aligned segment */
  strcpy(filename,B->IP->Datafiles->filename);
  strcat(filename,".alignment");
  align_fptr=fopen(filename,"w");

  /* find out the alignment */
  for(k=0;k<=Nblocks;k++){
      max=0;
      for(i=1;i<=B->Seq->SeqLen[0];i++){
	  for(j=1;j<=B->Seq->SeqLen[1];j++){
	      if(SK->profile[i][j]>max){
		  max=SK->profile[i][j];
		  max_i=i;
		  max_j=j;
	      }
	  }
      }
      if(max==0){
	  Nblocks=k;
	  break;
      }
      fprintf(align_fptr,"k=%d, max=%d, i=%d, j=%d\n",k,max,max_i,max_j);
      /* mark the alignment */
      /* go down stream */
      i1=max_i;
      j1=max_j;
      while(i1>=1 && j1>=1 && SK->profile[i1][j1]>=0.25*max){
	  SK->profile[i1][j1]=0;
	  i1--;
	  j1--;
      }
      fprintf(align_fptr," x1=%d,  y1=%d\n",i1+1,j1+1);
      x_start[k]=i1+1;
      y_start[k]=j1+1;
      /* go up stream */
      i2=max_i+1;
      j2=max_j+1;
      while(i2<=B->Seq->SeqLen[0] && j2<=B->Seq->SeqLen[1] 
	    && SK->profile[i2][j2]>=0.25*max){
	  SK->profile[i2][j2]=0;
	  i2++;
	  j2++;
      }
      fprintf(align_fptr," x2=%d,  y2=%d\n\n",i2-1,j2-1);
      x_end[k]=i2-1;
      y_end[k]=j2-1;
      /* mark (i1,j1) -(i2,j2) to zero */
      for(i=0;i<=x_end[k];i++)
	  for(j=y_start[k];j<=B->Seq->SeqLen[1];j++)
	      SK->profile[i][j]=0;
      for(i=x_start[k];i<=B->Seq->SeqLen[0];i++)
	  for(j=0;j<=y_end[k];j++)
	      SK->profile[i][j]=0;  
  } 

  /* put them in order */
  for(k=0;k<Nblocks-1;k++){
      for(i=k+1;i<Nblocks;i++){
          if(x_start[i]<x_start[k]){
	      pos=x_start[i];
	      x_start[i]=x_start[k];
	      x_start[k]=pos;

	      pos=y_start[i];
	      y_start[i]=y_start[k];
	      y_start[k]=pos;

	      pos=x_end[i];
	      x_end[i]=x_end[k];
	      x_end[k]=pos;

	      pos=y_end[i];
	      y_end[i]=y_end[k];
	      y_end[k]=pos;
	  }
      }
  }

  for(k=0;k<Nblocks;k++){
      fprintf(align_fptr,"%3d ",x_start[k]);
      for(i=x_start[k];i<=x_end[k];i++)
	  fprintf(align_fptr,"%c",
		  (char )(SEQ2CH(B->Seq->Orig[0][i-1])+65));
      fprintf(align_fptr," %3d\n",x_end[k]);
      fprintf(align_fptr,"%3d ",y_start[k]);
      for(j=y_start[k];j<=y_end[k];j++)
	  fprintf(align_fptr,"%c",
		  (char )(SEQ2CH(B->Seq->Orig[1][j-1])+65));
      fprintf(align_fptr," %3d\n\n",y_end[k]);
  }
  fclose(align_fptr);

  /* free space for ends of aligned segments */
  free(x_start);
  free(x_end);
  free(y_start);
  free(y_end);

}

/******************* Sankoff_Make_S  ********************************/
/*                                                                  */
/*     fill in score matrix with specific blocks                    */
/********************************************************************/

void Sankoff_Make_S(Stype Seq, Sank_S SK)
{
   
    float *s_ptr,**s_pptr,**s_pptr0;
    short *x_ptr;
    float *sum_ptr;
    float tmp;
    int L0,L1;
    short *Orig0,*Orig1;  /* for quick access */
    register int i,j,k,n,m;
    int   Nmatrix,matrix_num;

    Nmatrix=SK->Nmatrix;
    L0=Seq->SeqLen[0];
    L1=Seq->SeqLen[1];
    Orig0=Seq->Orig[0];
    Orig1=Seq->Orig[1];

    for(n=0;n<Nmatrix;n++){
         if(Nmatrix>1)
	     matrix_num=n;
	 else
	     matrix_num=SK->matrix_num;

        /* initialize the SUM matrix */
        for(i=1;i<=Seq->SeqLen[0];i++){
            #pragma MP serial_loop
	    for(j=1;j<=Seq->SeqLen[1];j++){
	        SK->SUM[i][j]=SK->SUM[i-1][j-1]+
	        f_related[matrix_num][Orig0[i-1]][Orig1[j-1]];
	    }
	}

	for(k=1;k<=SK->Sankoff_blocks;k++){
	    /* initialize the X matrix */
            #pragma MP serial_loop_nested
	    for(i=1;i<=L0;i++){	
	        x_ptr=SK->X[i];
	        for(j=1;j<=L1;j++){
		    x_ptr[j]=0;
		}
	    }
	    s_pptr=SK->S[n][k];
	    s_pptr0=SK->S[n][k-1];
	    for(i=1;i<=L0;i++){
	        s_ptr=s_pptr[i];
		for(j=1;j<=L1;j++){	
		    if(f_related[matrix_num]
                            [Orig0[i-1]][Orig1[j-1]]>0){   
                        /* it is possible at the end of the block */
		        /* find the max among three choice */
		        tmp=SA(Seq->Orig,s_pptr0,s_pptr,i,j,matrix_num,SK);
		        if(tmp>s_pptr[i][j-1]){
			    if(tmp>s_pptr[i-1][j]){
			        s_ptr[j]=tmp;
				SK->X[i][j]=1;	
			    }
			    else{
			        s_ptr[j]=s_pptr[i-1][j];
			    }
			}
			else if(s_pptr[i][j-1]>s_pptr[i-1][j]){
			    s_ptr[j]=s_pptr[i][j-1];
			}
			else{
			    s_ptr[j]=s_pptr[i-1][j];
			}
		    }
		    else{
		        /* it is not possible at the end of the block */
		        /* find the max among two choice */
		        if(s_pptr[i][j-1]>s_pptr[i-1][j]){
			    s_ptr[j]=s_pptr[i][j-1];
			}
			else{
			    s_ptr[j]=s_pptr[i-1][j];
			}
		    }
		}
	    }		
	}
    }
}

/*******************  Sankoff_Trace_S  ********************************/
/*                                                                    */
/*     strace back score matrix with specific blocks                  */
/**********************************************************************/

void Sankoff_Trace_S(Model B, Sank_S SK)
{

    Stype Seq=B->Seq;
    float **s_pptr,**s_pptr0,**s_pptr1;
    float tmp,tmp_max;
    int gap_x,gap_y;
    int ntraverse; /* number of element traverse */
    register int i,j,k,K,m,n,N,t;
    int Nmatrix,matrix_num;
    double Ln2=log(2);
    double posterior,map,margin;

    Nmatrix=SK->Nmatrix;
    for(N=0;N<Nmatrix;N++){
        if(Nmatrix>1){/* multiple matrices */
	    matrix_num=N;
	}
	else{
	    matrix_num=SK->matrix_num;
	}        
	fprintf(B->IP->Datafiles->out_fpt,
		"Matrix #%d\n\n",matrix_num);	
        for(K=1;K<=SK->Sankoff_blocks;K++){
	    k=0;
	    t=1;
	    s_pptr0=SK->S[N][K-k-1];
	    s_pptr=SK->S[N][K-k];

	    i=Seq->SeqLen[0];
	    j=Seq->SeqLen[1];
	    tmp_max=s_pptr[i][j];
	    fprintf(B->IP->Datafiles->out_fpt,
		    "k=%d, Max score=%g\n",K,tmp_max);

	    while(i>=1 && j>=1 && k<=K-1){
	        if(f_related[matrix_num]
                        [Seq->Orig[0][i-1]][Seq->Orig[1][j-1]]>=0){
		    /* it is possible at the end of a block */
		    if( s_pptr[i][j]>s_pptr[i-1][j] &&
			s_pptr[i][j]>s_pptr[i][j-1])
		      /* because the error over floating addition*/
		      /* we have to be careful of comparison     */
		    {
			tmp=SB(Seq->Orig,s_pptr0,i,j,&ntraverse,matrix_num,SK);
			SK->end_x[K][t]=i;
			SK->end_y[K][t]=j;
			SK->start_x[K][t]=i-ntraverse+1;
			SK->start_y[K][t]=j-ntraverse+1;
			t++;

			i=i-(ntraverse);
			j=j-(ntraverse);
			/* check the next matrix */
			k++;
			s_pptr0=SK->S[N][K-k-1];
			s_pptr=SK->S[N][K-k];
		    }
		    else if(s_pptr[i][j]>s_pptr[i][j-1])
		        /* we do not use == for floating point */
		        i--;
		    else
		        j--;
		}
		else{ /* not possible at the end */ 
		    if(s_pptr[i][j]>s_pptr[i][j-1])
		        /* we do not use == for floating point */
		        i--;
		    else
		        j--;
		}
	    }
	    /* out put the matching string */
	    if(SK->flags.output_sequence){
	        for(k=K;k>=1;k--){	    
		    if(SK->start_x[K][k]!=0){
		        fprintf(B->IP->Datafiles->out_fpt,"%3d ",
				SK->start_x[K][k]); 
			for(n=SK->start_x[K][k];n<=SK->end_x[K][k];n++){
			    fprintf(B->IP->Datafiles->out_fpt,"%c",
				    (char )(SEQ2CH(Seq->Orig[0][n-1])+65)); 
			}
			fprintf(B->IP->Datafiles->out_fpt,"% 3d\n",
				SK->end_x[K][k]);
			fprintf(B->IP->Datafiles->out_fpt,"%3d ",
				SK->start_y[K][k]); 
			for(n=SK->start_y[K][k];n<=SK->end_y[K][k];n++){
			    fprintf(B->IP->Datafiles->out_fpt,"%c",
				    (char )(SEQ2CH(Seq->Orig[1][n-1])+65)); 
			}
			fprintf(B->IP->Datafiles->out_fpt,"% 3d\n",
				SK->end_y[K][k]);
			fprintf(B->IP->Datafiles->out_fpt,"\n");
		    }	    
		}
	    }

	    /* posterior probability */
	    map=exp(SK->S[N][K][Seq->SeqLen[0]][Seq->SeqLen[1]]/2.*Ln2)/
	         SK->N[K];

	    margin=SK->W[N][K]/SK->N[K];
	    posterior=map/margin;
	    fprintf(B->IP->Datafiles->out_fpt,
		    "k=%d, W[k]=%g, N[k]=%g\n"
		    "S[k]/N[k]=%g, W[k]/N[k]=%g, S[k]/W[k]=%g\n",
		    K,SK->W[N][K],SK->N[K],map,margin,posterior);

	    /* posterior of k>0 */
	    posterior=0;
	    for(i=1;i<=K;i++)
	      posterior+=SK->W[N][i]/SK->N[i];
	    posterior=posterior/(float)K;
	    fprintf(B->IP->Datafiles->out_fpt,
		    "P(k>0|R)=%g\n",posterior/(1.+posterior));	  

	    /* score difference and expect score difference */
	    fprintf(B->IP->Datafiles->out_fpt,
		    "score difference=%3f, expected score difference=%f\n\n",
		    SK->S[N][K][Seq->SeqLen[0]][Seq->SeqLen[1]]-
		    SK->S[N][K-1][Seq->SeqLen[0]][Seq->SeqLen[1]], 
		    SC(B,SK,K));
	}
    }
}

/**************  Sankoff_probability_N   ***************************/
/*                                                                 */
/*  This function calculates total number of alignment.            */
/*                                                                 */
/*******************************************************************/

void Sankoff_probability_N(Model B,Sank_S SK )
{
  register int i,j,k,n;
  double **nd_pptr,**nr_pptr;   /* pointer for quick access */
  double **nd_pptr0,**nr_pptr0; /* pointer for quick access */
  double **nc_pptr;
  int    Len0,Len1;

  Len0=B->Seq->SeqLen[0];
  Len1=B->Seq->SeqLen[1];

  /* calculating N */
  /* value for no matching blocks */
  SK->N[0]=1;
    
  for(k=1;k<=SK->Sankoff_blocks;k++){
      nd_pptr=SK->ND[k%2];
      nd_pptr0=SK->ND[(k-1)%2];
      nr_pptr=SK->NR[k%2];
      nr_pptr0=SK->NR[(k-1)%2];
      nc_pptr=SK->NC[k%2];
      
      for(i=1;i<=Len0;i++){
	  for(j=1;j<=Len1;j++){
	      nd_pptr[i][j]=nc_pptr[i-1][j]+nd_pptr[i-1][j];
	      nr_pptr[i][j]=nc_pptr[i][j-1]+nd_pptr[i][j-1]+
		            nr_pptr[i][j-1];
	      nc_pptr[i][j]=nd_pptr0[i-1][j-1]+nr_pptr0[i-1][j-1]+
			     nc_pptr[i-1][j-1];
	  }
      }
      SK->N[k]=nd_pptr[Len0][Len1]+
	       nr_pptr[Len0][Len1]+
	       nc_pptr[Len0][Len1];

      /* let the W[k] be the exactly with k blocks */
      SK->N[k]=SK->N[k]-SK->N[k-1];
  } 
}

/**************  Sankoff_probability_W   ***************************/
/*                                                                 */
/*  This function calculates the sum of all probability,           */
/*  then use it to calculate the posterior probabilty.             */
/*                                                                 */
/*******************************************************************/

void Sankoff_probability_W(Model B,Sank_S SK )
{
  register int i,j,k,n;
  int    Nmatrix;               /* number of matrices used  */
  double **wd_pptr,**wr_pptr;   /* pointer for quick access */
  double **wd_pptr0,**wr_pptr0; /* pointer for quick access */
  double **wc_pptr;
  double *p_ptr;
  double sum,sumk;
  int    Len0,Len1;

  Len0=B->Seq->SeqLen[0];
  Len1=B->Seq->SeqLen[1];

  Nmatrix=SK->Nmatrix;

  /* value for no matching blocks */
  for(n=0;n<Nmatrix;n++)
      SK->W[n][0]=1;

  for(n=0;n<Nmatrix;n++){
      /* calculate the sum of probability */
      for(k=1;k<=SK->Sankoff_blocks;k++){
	  wd_pptr=SK->WD[0][k];
	  wd_pptr0=SK->WD[0][k-1];
	  wr_pptr=SK->WR[0][k];
	  wr_pptr0=SK->WR[0][k-1];
	  wc_pptr=SK->WC[0][k];

	  for(i=1;i<=Len0;i++){
	      p_ptr=SK->P[n][i];
	      for(j=1;j<=Len1;j++){
	          wd_pptr[i][j]=wc_pptr[i-1][j]+wd_pptr[i-1][j];
	          wr_pptr[i][j]=wc_pptr[i][j-1]+wd_pptr[i][j-1]+
		            wr_pptr[i][j-1];
	          wc_pptr[i][j]=(wd_pptr0[i-1][j-1]+wr_pptr0[i-1][j-1]+
			     wc_pptr[i-1][j-1])*p_ptr[j];
	      }
	  }
	  SK->W[n][k]=wd_pptr[Len0][Len1]+
	       wr_pptr[Len0][Len1]+
	       wc_pptr[Len0][Len1];

	  /* let the W[k] be the exactly with k blocks */
	  SK->W[n][k]=SK->W[n][k]-SK->W[n][k-1];
      }
  }
  /* calculate PK,PSI,PKSI */
  for(n=0;n<Nmatrix;n++){
      sum=0;
      for(k=1;k<=SK->Sankoff_blocks;k++){
	  sum+=(SK->W[n][k]/SK->N[k]);
      }
      sum=sum*0.5/SK->Sankoff_blocks+0.5;
      SK->PKSI[n][0]=0.5/sum;
      for(k=1;k<=SK->Sankoff_blocks;k++){
	  SK->PKSI[n][k]=(SK->W[n][k]/SK->N[k])*0.5/
	    (SK->Sankoff_blocks*sum);
      }      
  }
  if(Nmatrix >1){/* multiple matrices */
     sum=0;
     for(n=0;n<Nmatrix;n++){
         for(k=1;k<=SK->Sankoff_blocks;k++){
	     sum+=(SK->W[n][k]/SK->N[k]);
	 }
     }
     sum=sum*0.5/(Nmatrix*SK->Sankoff_blocks)+0.5;

     /* calculate PK */     
     SK->PK[0]=0.5/sum;
     for(k=1;k<=SK->Sankoff_blocks;k++){
         sumk=0;
	 for(n=0;n<Nmatrix;n++){
	     sumk+=SK->W[n][k]/SK->N[k];
	 }
	 sumk=sumk*0.5/(Nmatrix*SK->Sankoff_blocks);
	 SK->PK[k]=sumk/sum;
     }
     
     /* calculate PSI */
     for(n=0;n<Nmatrix;n++){
         sumk=0;
	 for(k=1;k<=SK->Sankoff_blocks;k++){
	     sumk+=SK->W[n][k]/SK->N[k];
	 }
	 sumk=sumk*0.5/(Nmatrix*SK->Sankoff_blocks);
	 SK->PSI[n]=sumk/sum;
     }     
  }     
}


/****************************** SA *******************************/
/*                                                               */
/*                                                               */
/*     calculate score along a block, stoped when it count last  */
/*     along the direction                                       */
/*     This subroutine is most time comsuming one. It counts half*/
/*     of all the calculation time.                              */
/*                                                               */
/*****************************************************************/

float SA(short** seq,float **score0,float**score, int i, int j,
         int matrix_num,Sank_S SK)
{
    register int m;
    float max;
    float tmp;
    short  **X=SK->X;        /* for quick access */
    float  **SUM=SK->SUM;
    short *seq0,*seq1;

    seq0=seq[0];
    seq1=seq[1];

    max=score0[i-1][j-1]+f_related[matrix_num][seq0[i-1]][seq1[j-1]];
    m=1;
    while(i-m>=1 && j-m>=1)
    {
        if(f_related[matrix_num][seq0[i-m-1]][seq1[j-m-1]]>0)
	{   /* it can be the start of a block */
	    if(X[i-m][j-m]==1)
	    {   /* merge with the previous block */
	        if((tmp=score[i-m][j-m]+SUM[i][j]-SUM[i-m][j-m])>max)
		    max=tmp;  
		return max;
	
	    }
	    if((tmp=score0[i-m-1][j-m-1]+SUM[i][j]-SUM[i-m-1][j-m-1])>max)
	    {
	        max=tmp;
	    }  		
	}
        m++;
    }
    return max;
}


/****************************** SB *******************************/
/*                                                               */
/*                                                               */
/*     calculate score along a block,also get the length of the  */
/*     block                                                     */
/*****************************************************************/

float SB(short ** seq,float **score, int i, int j,
	 int* traverse, int matrix_num,Sank_S SK)
{

    int m;
    float sum,s0,s1;

    sum=0;
    m=1;
    s0=0;
    while(i-m>=0 && j-m>=0)
      {
	s0+=f_related[matrix_num][seq[0][i-m]][seq[1][j-m]];
        if(s0+score[i-m][j-m]>=sum) 
          {
            sum=s0+score[i-m][j-m];
            *traverse=m;
          }
        m++;
      }
    return sum;
}
    
/******************************** SC ************************/
/*                                                          */
/*  calculate the expected score from statistics            */
/************************************************************/

double SC(Model B, Sank_S SK,int K)
{
  int i,j;
  int N=0;             /* sum(unmatched X*unmatch Y)  */
  int start_x,start_y; /* start of unmatching blocks  */
  int nx,ny;           /* length of unmatching blocks */
  double Kp,score;    

  start_x=1;
  start_y=1;
  for(i=K-1;i>=1;i--)
    {
      if(SK->start_x[K][i]!=0)
	{
	  nx=SK->start_x[K][i]-start_x;
	  ny=SK->start_y[K][i]-start_y;
	  N=N+nx*ny;
	  start_x=SK->end_x[K][i]+1;
	  start_y=SK->end_y[K][i]+1;
	}	    
    }
  /* the unmatching blocks at the tail */
  if(start_x <=B->Seq->SeqLen[0] && start_y <=B->Seq->SeqLen[1])
    N=N+(B->Seq->SeqLen[0]-start_x)*(B->Seq->SeqLen[1]-start_y);
  
  /* calculate the expected score with 0.1 probability */
  Kp=7.227e7;
  score=log(Kp*N);
  return score;
}

/* find the maximum number */
int max3(int a,int b, int c)
{
  int d;
  d=a;
  if(b>d)
    d=b;
  if(c>d)
    d=c;
  return d;
}


