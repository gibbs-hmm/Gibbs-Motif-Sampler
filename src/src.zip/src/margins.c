/****************************************************************/
/* Gibbs - A program for detecting subtle sequence signals      */
/*                                                              */
/* Please acknowledge the program authors on any publication of */
/* scientific results based in part on use of the program and   */
/* cite the following articles in which the program was         */
/* described.                                                   */
/* For data involving protein sequences,                        */
/* Detecting subtle sequence signals: A Gibbs sampling          */
/* strategy for multiple alignment. Lawrence, C. Altschul,      */
/* S. Boguski, M. Liu, J. Neuwald, A. and Wootton, J.           */
/* Science, 262:208-214, 1993.                                  */
/* and                                                          */
/* Bayesian models for multiple local sequence alignment        */
/* and Gibbs sampling strategies, Liu, JS. Neuwald, AF. and     */
/* Lawrence, CE. J. Amer Stat. Assoc. 90:1156-1170, 1995.       */
/* For data involving nucleotide sequences,                     */
/* Gibbs Recursive Sampler: finding transcription factor        */
/* binding sites. W. Thompson, E. C. Rouchka and                */
/* C. E. Lawrence, Nucleic Acids Research, 2003,                */
/* Vol. 31, No. 13 3580-3585.                                   */
/*                                                              */
/* Copyright (C) 2006   Health Research Inc.                    */
/* HEALTH RESEARCH INCORPORATED (HRI),                          */
/* ONE UNIVERSITY PLACE, RENSSELAER, NY 12144-3455.             */
/* Email:  gibbsamp@wadsworth.org                               */
/*                                                              */
/****************************************************************/
/*                                                              */
/* Changes Copyright (C) 2007   Brown University                */
/* Brown University                                             */
/* Providence, RI 02912                                         */
/* Email:  gibbs@brown.edu                                      */
/*                                                              */
/* For the Centroid sampler, please site,                       */
/* Thompson, W.A., Newberg, L., Conlan, S.P., McCue, L.A. and   */
/* Lawrence, C.E. (2007) The Gibbs Centroid Sampler             */
/* Nucl. Acids Res., doi:10.1093/nar/gkm265                     */
/*                                                              */
/* For the Phylogenetic Gibbs Sampler, please site,             */
/* Newberg, L., Thompson, W.A., Conlan, S.P., Smith, T.M.,      */
/* McCue, L.A. and Lawrence, C.E. (2007) A phylogenetic Gibbs   */
/* sampler that yields centroid solutions for cis regulatory    */
/* site prediction., Bioinformatics,                            */
/* doi:10.1093/bioinformatics/btm241.                           */
/*                                                              */
/****************************************************************/
/*                                                              */
/* This program is free software; you can redistribute it       */
/* and/or modify it under the terms of the GNU General Public   */
/* License as published by the Free Software Foundation;        */
/* either version 2 of the License, or (at your option)         */
/* any later version.                                           */
/*                                                              */
/* This program is distributed in the hope that it will be      */
/* useful, but WITHOUT ANY WARRANTY; without even the implied   */
/* warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR      */
/* PURPOSE. See the GNU General Public License for more         */
/* details.                                                     */
/*                                                              */
/* You should have received a copy of the GNU General Public    */
/* License along with this program; if not, write to the        */
/* Free Software Foundation, Inc., 51 Franklin Street,          */
/* Fifth Floor, Boston, MA  02110-1301, USA.                    */
/****************************************************************/

#include "margins.h"

#define FLANK       5

int PrintSeqMargins(Model B, int seq);
void PrintMarginSite(Model B, int seq, int siteCount, int start, int end);
void PrintMarginsFile(Model B);
void PrintMarginSeq(Model B, int seq, FILE *fpt, int colorTable[][5]);
void ColorTableLookup(int count, int samples, int colorTable[][5], char *color);
int IsCentroidPos(Model B, int seq, int pos);


void PrintMargins(Model B)
{
  IPtype IP;
  int    seq;
  int    totalSites = 0;
  FILE   *fpt;

  IP = B->IP;

  for( seq = 0; seq < IP->nNumSequences; seq++ )
    totalSites += PrintSeqMargins(B, seq);

  fpt = B->IP->Datafiles->out_fpt;
  fprintf( fpt, "\n%d Sites with marginal probability > %g\n", totalSites, 1.0/(1.0+IP->bayesGamma));
  
  if( totalSites ) {
    fprintf( fpt, "\nColumn 1 :  Sequence Number, Site Number\n" );
    fprintf( fpt, "Column 2 :  Left End Location\n" );
    fprintf( fpt, "Column 4 :  Motif Element\n" );
    fprintf( fpt, "Column 6 :  Right End Location\n" );
    fprintf( fpt, "Column 8 :  Sequence Description from FastA input\n\n" );
  }

  if(IP->Datafiles->marginFileName)
    PrintMarginsFile(B);
}


int PrintSeqMargins(Model B, int seq)
{
  RPType RP;
  IPtype IP;
  int    nLen;
  int    samples;
  int    nWidths;
  int    pos;
  int    n;
  int    cnt;
  int    start;
  int    end = 0;
  int    w;
  int    siteCount;
  double minMarginProb;
  double prob;
  int    minWidth;
  int    *counts;
  
  IP = B->IP;
  RP = B->RP;

  minWidth = MinPossibleWidth( B );
  nWidths = NumWidths( B ); 
  nLen = SequenceLength( B, seq );

  samples = IP->bayesSamplePeriod * IP->nSeeds;
  minMarginProb = 1.0/(1.0+IP->bayesGamma);

  NEW(counts, nLen, int);

  for(n = 0; n < nLen; n++) {
    for(w = 0; w < nWidths; w++) {
      cnt = RP->totalPosCounts[seq][n][w];
      for(pos = n; pos < n+minWidth+w; pos++)
	if(pos < nLen)
	  counts[pos] += cnt;
    }
  }

  siteCount = 0;
  for(n = 0; n < nLen; n++) {
    prob = (double) counts[n] / samples;
    if(prob > minMarginProb) {
      start = n;
      while(prob > minMarginProb) {
	end = n;
	n++;
	prob = (double) counts[n] / samples;
      }
      siteCount++;
      PrintMarginSite(B, seq, siteCount, start, end);
    }
  }

  free(counts);

  return(siteCount);
}


void PrintMarginSite(Model B, int seq, int siteCount, int start, int end)
{
  FILE     *fpt;
  char     *letters;
  char     *desc;
  int      i;
  int      j;
  int      maxWidth;
  int      width;
  int      nLen;
  int      pos;
  int      seqStart;

  nLen = SequenceLength( B, seq );
  seqStart = SequenceStartPos( B, seq );
  pos = start;

  width = end - start + 1;
  maxWidth = MaxPossibleWidth( B );  
  NEW( desc, max( maxWidth + 1, 51 ), char );

  fpt = B->IP->Datafiles->out_fpt;
  letters = &((*B->Seq->R)[seqStart]);

  fprintf( fpt, "%5d, %d %7d ", seq + 1, siteCount, start + 1 );	  
  for( j = 0, i = max( 0, start - FLANK ); i < pos; i++, j++ ) {
    desc[j] = curr_ch( letters[i], B->IP->nAlphaLen, FALSE );
  }
  desc[j] = '\0';
  fprintf( fpt, "%5s", desc );
  fprintf( fpt, " " );

  memset( desc, ' ', maxWidth );
  desc[maxWidth] = '\0';
  for( j = 0; j < width; j++, pos++ ) {
    desc[j] =  curr_ch( letters[pos], B->IP->nAlphaLen, TRUE );
  }
  fprintf( fpt, "%s", desc );
  fprintf( fpt, " " );

  for( j = 0, i = pos; i < min( pos + FLANK, nLen); i++, j++ ) {
    desc[j] = curr_ch( letters[i], B->IP->nAlphaLen, FALSE );
  }
  desc[j] = '\0';
  fprintf( fpt, "%5s", desc );
  fprintf( fpt, " %7d", pos );

  fprintf( fpt, " ");
  strncpy( desc, B->IP->fastaHeader[seq], 50 );
  fprintf(fpt, "%s\n", desc);

  free(desc);
}


void PrintMarginsFile(Model B)
{
  int        colorTable[10][5] = {{ 0,  10,   0,     0,    0},
				  {10,  20,   0,     0,  255},
				  {20,  30,   0,    85,  255},
				  {30,  40,   0,   170,  255},
				  {40,  50,   0,   255,  255},
				  {50,  60,  85,   255,   85},
				  {60,  70, 170,   255,   85},
				  {70,  80, 205,   205,    0},
				  {80,  90, 255,   170,    0},
				  {90, 100, 255,    85,    0}};
  FILE       *fpt;
  int        i;
  int        seq;
  
  fpt = B->IP->Datafiles->margin_fpt;
    
  fprintf(fpt, "<HTML>\n");
  fprintf(fpt, "<HEAD>\n");
  fprintf(fpt, "<TITLE>%s</TITLE>\n", B->IP->Datafiles->marginFileName);
  fprintf(fpt, "</HEAD>\n");
  fprintf(fpt, "<BODY style=\"font-family:courier;font-size:80%%;color:black\">");

  fprintf(fpt, "Color Code:<br>");

  for(i = 0; i < 10; i++) {
    if(colorTable[i][0] == 0) 
      fprintf(fpt, "<font color=\"#%02x%02x%02x\"> &nbsp;&nbsp %d - %d%%</font><br>",
	      colorTable[i][2], colorTable[i][3], colorTable[i][4],colorTable[i][0], colorTable[i][1]);
    else
      fprintf(fpt, "<font color=\"#%02x%02x%02x\"> > %d - %d%%</font><br>",
	      colorTable[i][2], colorTable[i][3], colorTable[i][4],colorTable[i][0], colorTable[i][1]);
  }
  fprintf(fpt, "<br>");

  fprintf(fpt, "<br><font color=\"black\">1--------10--------20--------30--------40--------50--------60</font>");
  fprintf(fpt, "<br><font color=\"black\">|--------|---------|---------|---------|---------|---------|</font><br><br>");

  for(seq = 0; seq < B->IP->nNumSequences; seq++)
    PrintMarginSeq(B, seq, fpt, colorTable);

  fprintf(fpt, "</BODY>\n");
  fprintf(fpt, "</HTML>\n");
}


void PrintMarginSeq(Model B, int seq, FILE *fpt, int colorTable[][5])
{
  RPType RP;
  IPtype IP;
  int    nLen;
  int    samples;
  int    nWidths;
  int    pos;
  int    n;
  int    cnt;
  int    w;
  int    minWidth;
  int    *counts;
  char   *color;
  int    seqStart;
  char   *letters;
  int    isSite;
  
  IP = B->IP;
  RP = B->RP;

  NEW(color, 32, char);

  minWidth = MinPossibleWidth(B);
  nWidths = NumWidths(B); 
  nLen = SequenceLength(B, seq);
  samples = IP->bayesSamplePeriod * IP->nSeeds;
  seqStart = SequenceStartPos( B, seq );

  letters = &((*B->Seq->R)[seqStart]);
  
  fprintf(fpt, ">%s<br>", B->IP->fastaHeader[seq]);

  NEW(counts, nLen, int);
  for(n = 0; n < nLen; n++) {
    for(w = 0; w < nWidths; w++) {
      cnt = RP->totalPosCounts[seq][n][w];
      for(pos = n; pos < n+minWidth+w; pos++)
	if(pos < nLen)
	  counts[pos] += cnt;
    }    
  }

  for(n = 0; n < nLen; n++) {
    isSite = IsCentroidPos(B, seq, n);
    if(isSite)
      fprintf(fpt, "<u>");
    memset(color, 0, 32);
    ColorTableLookup(counts[n], samples, colorTable, color);
    fprintf(fpt, "<font color=\"%s\">%c</font>", color, curr_ch(letters[n], IP->nAlphaLen, TRUE));
    if(isSite)
      fprintf(fpt, "</u>");
    if(n > 0 && n % 60 == 0)
      fprintf(fpt, "<br>");
  }
  fprintf(fpt, "<p></p>");
    
  free(color);
  free(counts);
}


void ColorTableLookup(int count, int samples, int colorTable[][5], char *color)
{
  double   pct;
  int      i;

  if(count == 0) {
    strcpy(color, "#000000");
    return;
  }

  pct = (((double) count)/samples) * 100;
  
  for(i = 0; i < 10; i++) {
    if(pct > colorTable[i][0] && pct <= colorTable[i][1]) {
      snprintf(color, 14, "#%02x%02x%02x", colorTable[i][2],  colorTable[i][3], colorTable[i][4]);
      return;
    }
  }
}


int IsCentroidPos(Model B, int seq, int pos)
{
  int   seqStart;

  seqStart = SequenceStartPos( B, seq );
  return(B->RP->centroidPos[seqStart+pos] == CENT_START || B->RP->centroidPos[seqStart+pos] == CENT_POS);
}
